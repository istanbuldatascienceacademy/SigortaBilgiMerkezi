# Copilot Atölyesi — IntelliJ adım adım kılavuz

> **Bağlam bir bütçedir.** Modele gönderdiğiniz her şey her istekte yeniden
> gönderiliyor ve her istekte yeniden faturalanıyor.

Bu kılavuz boş bir makineden başlayıp dört labın sonuna kadar her adımı
yürütür. Her adımda üç şey var: **ne yaptığınız**, **çalıştıracağınız komut** ve
**görmeniz gereken çıktı**. Gördüğünüz çıktı yazandan farklıysa devam etmeyin.

**Bu kılavuz IntelliJ IDEA ve diğer JetBrains IDE'ler içindir.** VS Code
kullanıyorsanız [`SIFIRDAN-YAPMA-KILAVUZU.md`](../../SIFIRDAN-YAPMA-KILAVUZU.md)
dosyasını açın.

---

## Ne gerekiyor

| | |
|---|---|
| **IDE** | IntelliJ IDEA (güncel sürüm) + GitHub Copilot eklentisi |
| **Hesap** | Copilot Business, Enterprise veya Free |
| **Python** | 3.10 veya üstü |
| **Süre** | Hazırlık ~25 dk · dört lab 3,5 saat |

---

## İçindekiler

<a id="toc"></a>

- [Bölüm 0 — Hazırlık](#hazirlik)
- [Lab 1 — Talimat dosyaları](#lab1) · 45 dk
- [Lab 2 — MCP sunucusu](#lab2) · 60 dk
- [Lab 3 — Ölçüm](#lab3) · 45 dk
- [Lab 4 — Optimizasyon](#lab4) · 60 dk
- [Sorun giderme](#sorun)

---

<a id="hazirlik"></a>

## Bölüm 0 — Hazırlık

**Süre:** 20–30 dakika · eğitimden önce, tek başınıza

Bu bölüm labların parçası değil; labların çalışması için gereken zemin.

### H1 · Python sürümünü kontrol edin

Terminalde:

```bash
python3 --version
```

**Görmeniz gereken:**

```
Python 3.12.3
```

Sürüm **3.10 veya üstü** olmalı.

> [!WARNING]
> Komut `python3 --version` — iki tire, aralarında boşluk yok. `python3 version`
> yazarsanız Python `version` adlı bir dosya arar ve hata verir.

<details>
<summary>Sorun çıkarsa</summary>

**`command not found`** — Python kurulu değil.
[python.org/downloads](https://python.org/downloads) adresinden kurun. Mac'te
Homebrew varsa `brew install python@3.12` de olur. Kurduktan sonra **yeni bir
terminal açıp** komutu tekrarlayın.

**Sürüm 3.10'un altında** — güncel bir sürüm kurun. `mcp` paketi 3.10+ istiyor
ve Lab 2 çalışmaz.

</details>

---

### H2 · IntelliJ'i ve Copilot eklentisini kurun

IntelliJ IDEA kurulu değilse
[jetbrains.com/idea/download](https://www.jetbrains.com/idea/download/)
adresinden indirin. Community Edition yeterli.

Sonra eklentiyi kurun:

1. `Settings/Preferences` → **Plugins**
2. **Marketplace** sekmesinde `GitHub Copilot` arayın
3. **Install** → IDE'yi yeniden başlatın

**Görmeniz gereken:** sağ alt köşedeki durum çubuğunda bir **Copilot ikonu**.

> [!IMPORTANT]
> Eklentinin **güncel** olduğundan emin olun. Eski sürümlerde ayarlarda
> **Model Context Protocol** bölümü hiç görünmüyor ve Lab 2 çalışmıyor.
> `Settings → Plugins → Installed` altından sürümü kontrol edin.

---

### H3 · Copilot planınızı kontrol edin

Tarayıcıda [github.com/settings/copilot](https://github.com/settings/copilot)
adresini açın.

**Görmeniz gereken:** aktif bir plan. Yoksa Copilot Free'yi etkinleştirin.

<details>
<summary>Kurumsal koltuk kullanıyorsanız</summary>

İki şeyin açık olması gerekir ve ikisi de yönetici işi:

- **Agent modu izni**
- **MCP sunucu izni**

MCP politikası şu an VS Code tarafında tanımlı; JetBrains geçiş sürecinde.
Yöneticinize **ikisini birden** sorun — kapı aynı yerde olmayabilir.

Politika kapalıysa MCP yapılandırması hiçbir şey yapmaz: sunucu görünmez, hata
da vermez.

</details>

---

### H4 · IntelliJ'de oturum açın

1. Sağ alttaki **Copilot ikonuna** tıklayın
2. **Sign in to GitHub** seçin
3. Açılan pencerede verilen **device code**'u kopyalayın
4. Tarayıcı açılır, kodu yapıştırın, yetkilendirin
5. IntelliJ'e dönün

**Görmeniz gereken:** Copilot ikonu artık gri değil, aktif durumda.

> [!NOTE]
> VS Code'dan farklı olarak JetBrains device code akışı kullanıyor. Tarayıcı
> otomatik açılmazsa açılan pencerede verilen adresi elle açın.

---

### H5 · Sohbet panelini açın ve Agent modunu seçin

`Tools` → **GitHub Copilot** → **Open Chat**

Ya da sağdaki araç çubuğundaki Copilot ikonuna tıklayın.

Panel açıldığında, giriş kutusunun yakınındaki **mod seçicisinden Agent**'ı
seçin.

**Görmeniz gereken:** panelin altında mod seçici ve **Agent** seçili.

> [!CAUTION]
> Ask modunda MCP araçları çalışmaz. Lab 2'nin tamamı Agent moduna bağlı.

---

### H6 · MCP'siz temel doğrulama yapın

Herhangi bir proje açın, bir dosya seçin ve sohbete yazın:

```
Bu dosyanın ne yaptığını iki cümleyle anlat.
```

**Görmeniz gereken:** dosyayı gerçekten okuduğunu belli eden bir cevap.

> [!TIP]
> Bu adımı atlamayın. Buraya kadar çalışıyorsa temel kurulum tamamdır. Sonra bir
> sorun çıkarsa **nerede olmadığını** bilirsiniz.

---

### H7 · Atölye reposunu açın

Repoyu klonlayın veya zip'i açın, sonra IntelliJ'de açın:

`File` → **Open** → repo kökünü seçin

> [!IMPORTANT]
> **Repo kökünü** seçin — `.github` ve `mcp_server` klasörlerini **içeren**
> dizini, bir üstünü değil.

IntelliJ'in terminalini açın (`View` → `Tool Windows` → **Terminal**) ve
doğrulayın:

```bash
pwd
ls -a
```

**Görmeniz gereken:**

```
.github  cost  labs  mcp_server  requirements.txt  tests
```

<details>
<summary><code>.github</code> görünmüyorsa</summary>

Ya `ls` yazdınız (gizli klasörler görünmez, `ls -a` gerekli) ya da zip açılırken
atlandı. `ls -a` ile tekrar bakın.

</details>

---

### H8 · Sanal ortam kurun

IntelliJ'in terminalinde:

```bash
python3 -m venv .venv
source .venv/bin/activate
```

Windows'ta ikinci satır: `.venv\Scripts\activate`

**Görmeniz gereken:** komut isteminin başında `(.venv)`.

> [!WARNING]
> **Neden sanal ortam:** sistem Python'ına kurmak iki şekilde patlıyor. macOS'ta
> Homebrew Python'ı izin vermiyor (`externally-managed-environment`), Anaconda
> kuruluysa paketler yanlış ortama gidiyor ve Lab 2'de sunucu çalışmıyor.
>
> `(.venv)` yeni terminal açtığınızda kaybolur — her seferinde
> `source .venv/bin/activate` çalıştırın.

---

### H9 · Paketleri kurun

```bash
python -m pip install -r requirements.txt
```

`pip` değil `python -m pip` kullanın — böylece kesinlikle aktif ortamın pip'i
çalışır.

**Doğrulayın:**

```bash
python -c "import mcp, pytest; print('paketler tamam')"
```

<details>
<summary>PyJWT çakışması çıkarsa</summary>

```bash
python -m pip install mcp --ignore-installed PyJWT
```

</details>

---

### H10 · Testleri çalıştırın

```bash
python -m pytest tests -q
```

**Görmeniz gereken:**

```
............................              [100%]
28 passed in 0.77s
```

> [!CAUTION]
> **28 passed görmeden devam etmeyin.** Sonraki her şey bunun üstüne kurulu.

---

### H11 · Python yorumlayıcısını IntelliJ'e tanıtın

`Settings/Preferences` → **Project: workshop** → **Python Interpreter**

Dişli ikonu → **Add** → **Existing environment** → `.venv/bin/python` yolunu
seçin.

**Görmeniz gereken:** paket listesinde `mcp` ve `pytest`.

> [!NOTE]
> Bu adım IntelliJ'in kodu doğru çözümlemesi için. Lab 2'de ayrıca aynı yolu
> MCP yapılandırmasına da yazacaksınız.

---

### H12 · İki tam yolu alın ve saklayın

```bash
echo "KOMUT  : $(pwd)/.venv/bin/python"
echo "ARGUMAN: $(pwd)/mcp_server/corp_server.py"
```

Windows'ta:

```
echo %CD%\.venv\Scripts\python.exe
echo %CD%\mcp_server\corp_server.py
```

**Bu iki satırı bir yere kopyalayın.** Lab 2'de ayar arayüzüne elle
yazacaksınız — JetBrains'te `${workspaceFolder}` gibi bir değişken yok.

---

**Hazırlık bitti.** Buradan sonrası eğitim günü.

[↑ İçindekiler](#toc)

---

<a id="lab1"></a>

## Lab 1 — Talimat dosyaları

**Süre:** 45 dakika · **Hedef:** Copilot'un davranışını dosyayla yönetmek ve her
dosyanın maliyet etkisini görmek

### 1.1 · Önce ölçün

Hiçbir dosyaya bakmadan sohbete sorun:

```
Bu projede para tutarları için hangi tipi kullanmalıyım?
```

**Görmeniz gereken:** genel bir cevap — *"BigDecimal genelde iyi bir seçim ama
duruma göre değişir"* gibi.

Cevabı bir yere yazın. Birazdan karşılaştıracaksınız.

> [!TIP]
> **Neden bu adım var:** talimat dosyasını önce eklerseniz farkı hiç
> göremezsiniz. Bugün yapacağınız her ölçümde bu sıra geçerli — **önce ölç,
> sonra değiştir**.

---

### 1.2 · Talimat dosyasını okuyun, aynı soruyu tekrar sorun

`.github/copilot-instructions.md` dosyasını açıp okuyun. Altı invariant var.

Sonra **yeni bir sohbet açıp** birebir aynı soruyu sorun.

**Görmeniz gereken:** kesin bir cevap — `BigDecimal`, asla `double`.

> [!WARNING]
> **Yeni sohbet şart.** Aynı sohbette sorarsanız ilk cevap hâlâ bağlamda durur
> ve ikincisi kirlenir. Lab 3'te aynı hata bütün ölçümünüzü bozar.

---

### 1.3 · Dosyaları tartın — ve neyin okunmadığını görün

```bash
python -c "
import sys; sys.path.insert(0,'.')
from cost.calculator import estimate_tokens
from pathlib import Path
t=0
for f in sorted(Path('.github').rglob('*.md')):
    n=estimate_tokens(f.read_text()); t+=n
    print(f'{n:>6} token  {f}')
print(f'{t:>6} token  TOPLAM')
"
```

**Görmeniz gereken:**

```
   279 token  .github/chatmodes/analyst.chatmode.md
   292 token  .github/copilot-instructions.md
   130 token  .github/instructions/data-jobs.instructions.md
   310 token  .github/instructions/java-service.instructions.md
   292 token  .github/prompts/analist.prompt.md
   188 token  .github/prompts/release-check.prompt.md
   221 token  .github/prompts/service-review.prompt.md
  1712 token  TOPLAM
```

Şimdi asıl mesele. **Bu 1712 token'ın hepsi IntelliJ'de okunmuyor:**

| Dosya | Token | IntelliJ'de |
|---|---|---|
| `copilot-instructions.md` | 292 | **Her istekte yüklenir** |
| `prompts/*.prompt.md` | 701 | Yalnızca `/komut` ile çağrılınca |
| `instructions/*.md` | 440 | **Okunmuyor** |
| `chatmodes/*.md` | 279 | **Okunmuyor** |

Yani her isteğe eklenen tek şey **292 token**. 719 token repoda duruyor ama
hiçbir şey yapmıyor.

> [!NOTE]
> Okunmayan dosyalar maliyet de üretmiyor — ama fayda da sağlamıyor. Ekibinizde
> hem VS Code hem IntelliJ kullanılıyorsa aynı repo iki kişide farklı
> davranıyor. Bu, Lab 1'in tartışma sorusu.

---

### 1.4 · Her satırı denetleyin

`copilot-instructions.md` dosyasını satır satır gezin ve her satır için sorun:

> Ekibimin sorduğu soruların yüzde kaçında bu satır gerçekten gerekli?

| Oran | Nereye ait |
|---|---|
| %80 ve üstü | Burada kalır |
| %20 – %80 | **Prompt dosyasına** (JetBrains'te `applyTo` yok) |
| %20 altı | Prompt dosyasına, istendiğinde çağrılır |

**Hedef:** 500 token altı. Repodaki örnek 292.

<details>
<summary>VS Code'da bu tablo neden farklıydı</summary>

VS Code'da orta satır `instructions/` klasörüne gidiyordu: `applyTo` globu
sayesinde bir Java kuralı, siz Python yazarken hiç yüklenmiyordu.

JetBrains bunu desteklemiyor. Kapsamlama fikri hâlâ doğru — ilgisiz bağlam hem
para yakıyor hem modeli şaşırtıyor — ama otomatik aracı yok. Siz çağrı düzeyinde
yapıyorsunuz: detayı prompt dosyasına koyup yalnızca gerektiğinde çağırmak aynı
işi görüyor, bir tık maliyetiyle.

</details>

**Uygulama:** `.github/instructions/java-service.instructions.md` dosyasını açın
(310 token, IntelliJ okumuyor). Şu soruyu bir cümleyle yanıtlayın:

> Bu içerik JetBrains'te nereye ait? Hepsi her isteğe mi girmeli, yoksa bir
> kısmı istendiğinde mi çağrılmalı?

Kararınızı yazın. Lab 4'te uygulayacaksınız.

---

### 1.5 · Prompt dosyalarını deneyin

Bir `.java` dosyası açıkken sohbete yazın:

```
/service-review
```

**Görmeniz gereken:** eğik çizgiyi yazdığınızda açılan listede `service-review`,
`release-check` ve `analist`.

<details>
<summary>Liste çıkmıyorsa</summary>

- `.github/prompts/` klasörünün olduğunu doğrulayın
- IntelliJ'in repo kökünü açtığını doğrulayın (H7)
- IDE'yi yeniden başlatın

</details>

#### Kendi promptunuzu yazın

Haftada en az bir kez tekrarladığınız bir işi seçin. `.github/prompts/` altına
dosya oluşturun:

```markdown
---
description: Değişiklikler için PR açıklaması yazar
mode: agent
---

# PR açıklaması

1. Değişen dosyaları incele.
2. Şu başlıklarla bir açıklama yaz:
   - Ne değişti (madde madde)
   - Neden
   - Nasıl test edildi
3. Kod değiştirme. Sadece metni ver.
```

Üç kural: **çok adımlı**, **açık çıktı biçimi**, **sonunda bir duruş**.

> [!IMPORTANT]
> JetBrains'te prompt dosyaları VS Code'dakinden daha önemli. `applyTo` ve chat
> mode olmadığı için, her istekte yüklenen dosyadan çıkardığınız her şeyin
> gideceği tek yer burası.

---

### 1.6 · Analist modunu deneyin

VS Code'da bu bir chat mode'du. JetBrains'te chat mode yok; davranışı prompt
dosyasıyla taşıyoruz.

`.github/prompts/analist.prompt.md` dosyasını açıp okuyun. Sonra sohbete:

```
/analist
```

Ardından sorun:

```
Sürüm takvimi kuralları nerede tanımlı ve ne diyor?
```

Sonra deneyin:

```
Bana bir servis sınıfı yaz.
```

**Görmeniz gereken:** ikincisini **reddetmeli**.

#### İki farkı not edin

| | Chat mode (VS Code) | Prompt dosyası (JetBrains) |
|---|---|---|
| Ne kadar sürer | Mod seçili kaldığı sürece | O sohbet boyunca |
| Araç erişimi | `tools` ile kısıtlanır | Kısıtlanamaz |
| Nasıl açılır | Mod menüsünden | `/analist` yazarak |

> [!NOTE]
> İkinci satır önemli: chat mode'da araç kısıtlaması bağlamı da küçültüyordu —
> az araç, az şema, ucuz cevap. Burada davranışsal sınır kalıyor, **maliyet
> kazancı kalmıyor**.

---

### Lab 1 çıktıları

- [ ] 1.1 ve 1.2'deki iki cevap yazılı, farkı görüldü
- [ ] Repodaki 1712 token'ın hangi kısmının okunduğu görüldü
- [ ] Kapsamlama olmadığında ne yapılacağına dair karar yazıldı
- [ ] Kendi `.prompt.md` dosyanız `/komut` ile çalıştı
- [ ] `/analist` denendi, reddedişi görüldü

**Tartışma soruları:**

1. Kurumunuzda bu dosyaları kim yazar ve kim onaylar? Bir geliştirici
   `copilot-instructions.md`'ye satır eklediğinde maliyet herkese yayılıyor.
   Bu dosya kod mudur, politika mıdır?
2. Ekibinizde hem VS Code hem IntelliJ kullanılıyorsa aynı repo iki kişide
   farklı davranıyor. En küçük ortak paydada mı buluşursunuz, yoksa her IDE için
   ayrı mı yazarsınız?

[↑ İçindekiler](#toc)

---

<a id="lab2"></a>

## Lab 2 — MCP sunucusu

**Süre:** 60 dakika · **Hedef:** kurum içi bir kaynağı Copilot'a araç olarak
açmak ve sınırlarını görmek

> [!IMPORTANT]
> **VS Code'dan en büyük fark bu labda.** Orada repoda duran bir
> `.vscode/mcp.json` dosyası vardı ve ekiple paylaşılıyordu. JetBrains'te
> yapılandırma IDE ayarlarında duruyor.

### 2.1 · Sunucuyu elle bir kez çalıştırın

IDE'ye dokunmadan önce, sunucunun çalıştığını kanıtlayın:

```bash
"$(pwd)/.venv/bin/python" "$(pwd)/mcp_server/corp_server.py"
```

**Görmeniz gereken:** hiçbir şey. Terminal donar ve bekler — **bu doğru**,
sunucu stdin dinliyor. `Ctrl+C` ile çıkın.

<details>
<summary>Sorun çıkarsa</summary>

**Traceback dökerse** — hata sunucu kodunda ya da kurulumda. Mesajı okuyun;
IDE'nin sizden saklayacağı şeyi burada görüyorsunuz.

**Hemen komut istemine dönerse** — komutu gerçek bir terminalde çalıştırdığınızdan
emin olun. IDE'nin "Run" düğmesiyle çalıştırırsanız stdin kapalı olur ve sunucu
sessizce çıkar.

**`no such file or directory`** — ya repo kökünde değilsiniz (`pwd`) ya da
`.venv` kurulmamış (`ls -d .venv`).

</details>

---

### 2.2 · MCP'yi ayar arayüzünden tanımlayın

1. Sağ alt köşedeki **Copilot ikonuna** tıklayın
2. **Edit Settings** seçin
3. **Model Context Protocol** bölümüne gidin
4. **Configure** düğmesine basın

Açılan `mcp.json` düzenleyicisine şunu yazın — **yolları H12'de aldığınız
değerlerle değiştirerek**:

```json
{
  "servers": {
    "corp-internal": {
      "type": "stdio",
      "command": "/BURAYA/KOMUT/YOLU",
      "args": ["/BURAYA/ARGUMAN/YOLU"]
    }
  }
}
```

`Ctrl+S` / `Cmd+S` ile kaydedin veya dosyayı kapatın.

> [!CAUTION]
> **Düz `python` yazmayın.** PATH'te ilk gelen yorumlayıcı çalışır — genelde
> sistem Python'ı veya Anaconda base ortamı. Orada `mcp` paketi olmadığı için
> süreç anında ölür ve **sebebi görünmez**.
>
> İki yolun da `.venv` içerdiğini kontrol edin.

#### Bunun üç sonucu

| | VS Code | IntelliJ |
|---|---|---|
| Yapılandırma nerede | Repoda, `.vscode/mcp.json` | IDE ayarlarında |
| Ekiple paylaşılır mı | Evet, commit edilir | **Hayır** |
| PR'da incelenir mi | Evet | **Hayır** |

> [!NOTE]
> Üçüncü satır bankada konuşulmaya değer: repoda duran bir yapılandırma
> incelenebilir bir karardır. IDE ayarında duran, kimsenin görmediği bir
> karardır.

---

### 2.3 · Sunucuyu doğrulayın

Sohbet panelini açın, **Agent** modunda olduğunuzu doğrulayın ve yazın:

```
standards_list aracını çalıştır
```

**Görmeniz gereken:** araç çağrısı için bir **izin istemi**. İzin verdiğinizde
üç standardın listesi dönecek: `java-service`, `data-access`,
`ai-assistant-usage`.

<details>
<summary>Sorun giderme</summary>

| Belirti | Sebep ve çözüm |
|---|---|
| Araç bilinmiyor diyor | Agent modunda değilsiniz |
| Sunucu başlamıyor | `command` yanlış yorumlayıcı — 2.2'ye dönün |
| Hiçbir şey olmuyor | IDE'yi tamamen kapatıp açın |
| Ayarlarda MCP bölümü yok | Copilot eklentisi eski; güncelleyin |
| Kurumsal hesapta kapalı | Yönetici politikası — eğitmene söyleyin |

</details>

---

### 2.4 · Üç soruyu sorun

Her birini **ayrı sohbette** sorun:

```
Hangi dahili API'ler kişisel veri içermiyor?
```

```
Bugün üretime çıkabilir miyiz?
```

```
14 Ağustos 2026'da deploy edebilir miyiz?
```

**Görmeniz gereken:** üçüncüsü **hayır** demeli ve gerekçesini de vermeli —
*"Month-end reconciliation window"*.

> [!TIP]
> **Buradaki asıl ders:** araç sadece `false` döndürmüyor, nedenini de
> döndürüyor. Model gerekçeyi uyduramıyor, alıntılamak zorunda.
>
> Her çağrıdan önce gelen izin istemini okuyun. O istem bu labın ana konusu: her
> araç çağrısı, bir insanın belirli bir anda verdiği bir karar. Denetim izini
> anlamlı kılan şey o.

---

### 2.5 · Geliştirici kolu — araç yazın

> Analistseniz [2.6 Analist kolu](#analist-kolu) adımına geçin.

`mcp_server/corp_server.py` dosyasında `tool_cost` fonksiyonunun **üstüne**
ekleyin:

```python
@mcp.tool()
def find_service_owner(service_name: str) -> str:
    """Bir servisten sorumlu ekibi döndürür.

    Kullanıcının bir servis hakkında kime başvuracağını bilmesi gerektiğinde
    kullan — kayıt açmadan veya olayı yükseltmeden önce. Elinde yalnızca
    kısmi bir isim varsa önce api_search çağır.

    Args:
        service_name: API kataloğundaki anahtar veya ad.
    """
    # gövdeyi siz yazın
```

Üç tasarım kuralı:

- Docstring **"ne zaman çağrılacağını"** söylesin, "ne yaptığını" değil — model
  araç seçimini buna bakarak yapıyor
- Bulunamayınca **mevcut seçenekleri döndürün** — model tahmin etmek yerine
  kendini düzeltebilsin
- **Kişisel veri döndürmeyin**

`tests/test_mcp_tools.py` dosyasının import satırına `find_service_owner`
ekleyin, sonra testleri yazın:

```python
def test_find_service_owner_returns_the_team():
    result = call(find_service_owner, service_name="limit-engine")
    assert result["owner_team"] == "Credit Technology"


def test_unknown_service_lists_alternatives():
    result = call(find_service_owner, service_name="nope")
    assert "error" in result
    assert "limit-engine" in result["available"]
```

```bash
python -m pytest tests -q
```

**Görmeniz gereken:** `30 passed`

<details>
<summary><code>NameError</code> alıyorsanız</summary>

Import satırını atladınız. `tests/test_mcp_tools.py` başındaki listeye
`find_service_owner` ekleyin.

</details>

#### Sunucuyu yeniden yükleyin

> [!WARNING]
> **JetBrains'te `MCP: Restart Server` komutu yok.** Copilot ayarlarından MCP
> yapılandırmasını açıp kaydedin, ya da IDE'yi yeniden başlatın.

Sonra sohbete: `Limit motorunun sahibi kim?`

---

<a id="analist-kolu"></a>

### 2.6 · Analist kolu — araçları değerlendirin

Araç yazmıyorsunuz. Daha zor olan soruyu yanıtlıyorsunuz: **hangi araç
olmamalı.**

`mcp_server/corp_server.py` dosyasını açın, beş docstring'i okuyun ve beş soruya
**yazılı** cevap verin:

1. Hangi açıklama modelin **yanlış aracı** seçmesine yol açabilir? Yeniden yazın.
2. `api_search` aracının `pii_free_only` parametresi olmasaydı ne bozulurdu?
3. Bu sunucuya **eklenmemesi** gereken bir araç söyleyin ve nedenini savunun.
   Somut olun: hangi veriyi döndüreceğini ve neyin ters gideceğini adıyla yazın.
4. `can_deploy` verdiktin yanında gerekçe de döndürüyor. Sadece `true`/`false`
   dönseydi ne kaybederdik?
5. **JetBrains'e özel:** yapılandırma repoda değil IDE ayarlarında duruyor. Bir
   denetçi *"bu ekip hangi MCP sunucularını bağlamış"* diye sorsa, cevabı
   nereden bulursunuz?

> [!NOTE]
> **Bu kolay kol değil.** Bankada asıl kritik soru bir aracın *yazılmaması*
> gerektiği, ve bu soru Python bilene değil iş sonucunu bilene ait.
> Değerlendirmede ilk siz sunuyorsunuz.

---

### 2.7 · Sunucunun maliyetini görün

```
tool_cost aracını çalıştır
```

Her aracın yaklaşık token sayısını ve toplamı göreceksiniz. Bu şemalar, **bu
sunucu bağlıyken yapılan her isteğe** gidiyor — sunucuyla hiç ilgisi olmayan
istekler dahil.

Hesabı yapın: sekizer araçlı on sunucu, sorduğunuz **her sorunun** başına seksen
araç şeması ekler. Copilot'un tavanı istek başına 128 araç, ama kalite bozulması
çok daha önce başlar — model bunlar arasından *seçmek* zorunda.

> [!TIP]
> **Kural:** bugün kullanmadığınız sunucuyu kapatın. Sunucu bağlamak bedava
> değil.

---

### Lab 2 çıktıları

- [ ] Sunucu elle çalıştırıldı ve dondu
- [ ] Ayar arayüzünden tam yollarla tanımlandı
- [ ] Üç soru soruldu, üçüncüsü gerekçeli hayır döndü
- [ ] Geliştirici: `find_service_owner` yazıldı, `30 passed`, canlı çalışıyor
- [ ] Analist: beş soruya yazılı cevap
- [ ] `tool_cost` çalıştırıldı, hesap yapıldı

**Tartışma soruları:**

1. Bu sunucu bilinçli olarak müşteri verisi döndürmüyor. Bir ekip müşteri
   sorgulama aracı yazmak isterse hangi onaylardan geçmeli — ve kararı kim verir?
2. Yapılandırma IDE ayarlarında durduğu için ekip genelinde görünür değil.
   Onaylı sunucu listesini nasıl uygularsınız?

[↑ İçindekiler](#toc)

---

<a id="lab3"></a>

## Lab 3 — Ölçüm

**Süre:** 45 dakika · **Hedef:** tahmini ölçümle değiştirmek

> [!NOTE]
> Bu lab IDE'den bağımsız. VS Code sürümüyle birebir aynı.

### 3.1 · Gerçek rakamınızı bulun

**GitHub → Settings → Billing → Usage**

Üç şeyi yazın:

| | Sizin rakamınız |
|---|---|
| Bu ay harcanan AI Credits | |
| Karışımdaki modeller | |
| Dahil kredinin yüzde kaçı | |

> [!CAUTION]
> **Bu adımı atlamayın.** Sonraki her şey bu rakama dayanıyor. Erişiminiz yoksa
> eğitmen kendi ekranını gösterecek — ama kurumunuzda **kimin** erişimi olduğunu
> öğrenin.
>
> *Tahminle bütçe kurmak, ölçmemenin kibarcasıdır.*

---

### 3.2 · Senaryo scriptini çalıştırın

```bash
python cost/scenarios.py
```

**Görmeniz gereken (son satırlar):**

```
Before optimisation        $ 3,064.32    134.4%
After model routing        $ 1,333.68     58.5%
After context discipline   $   456.37     20.0%

Total saving: $2,607.95/month · $31,295.38/year
```

---

### 3.3 · Kendi ekibinize kalibre edin

`cost/scenarios.py` dosyasını açın, en üstteki üç sabiti değiştirin:

```python
SEATS = 120           # kendi ekip büyüklüğünüz
WORKDAYS = 21
ALLOWANCE = 19.0      # Business 19, Enterprise 39
```

Sonra `baseline` profilindeki `interactions_per_dev_per_day` listesini kendi
ekibinizin çalışma biçimine göre yazın. Tekrar çalıştırıp **3.1'deki gerçek
rakamla karşılaştırın.**

> [!IMPORTANT]
> Fark büyükse hatalı olan hesaplayıcı değil, sizin kullanım varsayımlarınız.
> Kabaca tutana kadar düzeltin. **Bu kalibrasyonun kendisi uygulamanın asıl
> kısmı.**

---

### 3.4 · Üç eşiği doğrulayın

#### a) Model seçimi — 25 kat

```bash
python -c "
import sys; sys.path.insert(0,'.')
from cost.calculator import Interaction
for m in ('gpt-5.6-luna','gpt-5.6-terra','gpt-5.6-sol'):
    i = Interaction(m, input_tokens=100_000, output_tokens=3_000)
    print(f'{m:>16}  \${i.cost_usd():.4f}  {i.credits():>6.1f} kredi')
"
```

**Görmeniz gereken:**

```
    gpt-5.6-luna  $0.0236     2.4 kredi
   gpt-5.6-terra  $0.2360    23.6 kredi
     gpt-5.6-sol  $0.5900    59.0 kredi
```

#### b) Önbellek — 10 kat

```bash
python -c "
import sys; sys.path.insert(0,'.')
from cost.calculator import Interaction
tam = Interaction('gpt-5.6-terra', input_tokens=100_000)
onb = Interaction('gpt-5.6-terra', cached_input_tokens=100_000)
print(f'tam        \${tam.cost_usd():.4f}')
print(f'onbellekli \${onb.cost_usd():.4f}')
print(f'oran       {tam.cost_usd()/onb.cost_usd():.1f}x')
"
```

**Görmeniz gereken:**

```
tam        $0.2000
onbellekli $0.0200
oran       10.0x
```

Şimdi dürüst tarafı:

```bash
python -c "
import sys; sys.path.insert(0,'.')
from cost.calculator import RATES
r = RATES['claude-sonnet-5']
print(f'girdi {r.input_}  onbellekli {r.cached_input}  yazma {r.cache_write}')
"
```

**Görmeniz gereken:** `girdi 2.0  onbellekli 0.2  yazma 2.5`

> [!NOTE]
> Önbelleğe **yazmak** düz girdiden pahalı. Önbellek bir yatırım — tekrar
> kullanımda geri dönüyor, kısa ömürlü bağlamda zarar bile ettirebiliyor.

#### c) Uzun bağlam — 2 kat

```bash
python -c "
import sys; sys.path.insert(0,'.')
from cost.calculator import Interaction
for n in (270_000, 280_000):
    i = Interaction('gpt-5.6-terra', input_tokens=n, output_tokens=3_000)
    print(f'{n:>9,} token -> \${i.cost_usd():.4f}')
"
```

**Görmeniz gereken:**

```
  270,000 token -> $0.5760
  280,000 token -> $1.1740
```

**%3,7 daha çok token, %104 daha çok para.** Kademe yok, 272K'da uçurum var.

---

### 3.5 · Kendinizi ölçün (A/B koşusu)

Bir görev seçin — örneğin *"şu servis çağrısına zaman aşımı ekle"*.

- **A koşusu:** bağlama beş dosya ekleyin, güçlü model, uzun süren bir sohbetin
  ortasında sorun
- **B koşusu:** yeni sohbet, sadece ilgili dosya, hafif model, net tek istek

İki koşu arasında GitHub kullanım raporunu kontrol edin.

| | A koşusu | B koşusu |
|---|---|---|
| Kullanılan model | | |
| Bağlamdaki dosya sayısı | | |
| Harcanan kredi | | |
| Cevap kabul edilebilir mi? | | |

**Beklenen büyüklük (modellenmiş örnek):**

| Değişen | Maliyet | Kazanç |
|---|---|---|
| Hiçbiri | $0,5110 | — |
| Yalnız model hafifledi | $0,0204 | 25x |
| Yalnız bağlam küçüldü | $0,0570 | 9x |
| İkisi birden | $0,0023 | **224x** |

> [!IMPORTANT]
> 25 × 9 = 225. **Kaldıraçlar toplanmıyor, çarpılıyor.**
>
> **Dördüncü satır boşsa ölçüm geçersizdir.** Kendinize sorun: B'nin cevabını
> gerçekten kullanır mıydınız, yoksa A'yı görmüş olduğunuz için mi kabul
> edilebilir göründü?

---

### Lab 3 çıktıları

- [ ] Gerçek kullanım rakamı yazıldı
- [ ] `scenarios.py` kendi ekip büyüklüğüne kalibre edildi
- [ ] Üç eşik kendi terminalinizde doğrulandı
- [ ] A/B koşusu yapıldı, **dört satır da** dolduruldu

[↑ İçindekiler](#toc)

---

<a id="lab4"></a>

## Lab 4 — Optimizasyon

**Süre:** 60 dakika · **Hedef:** ölçtüğünüz rakamı düşürmek, sonra tekrar ölçmek

> [!NOTE]
> Bu lab da IDE'den bağımsız — tek fark, Adım 4.2'de içeriğin gideceği yer
> olarak `instructions/` yerine prompt dosyaları kullanılması.

### 4.1 · Her dosyayı tartın

```bash
python -c "
import sys; sys.path.insert(0,'.')
from cost.calculator import estimate_tokens
from pathlib import Path
toplam = 0
for f in sorted(Path('.github').rglob('*.md')):
    t = estimate_tokens(f.read_text()); toplam += t
    print(f'{t:>6} token  {f}')
print(f'{toplam:>6} token  TOPLAM')
"
```

Şimdi **kendi reponuzda** çalıştırın. O rakam bugün üzerinde çalışacağınız şey.

> [!WARNING]
> Tahminler sadece sezgi için. Gerçek tokenizasyon modele özgü ve **Türkçe metin
> aynı içerik için İngilizceden belirgin biçimde fazla token üretiyor.** Rapor
> edeceğiniz hiçbir şeyde tahmin kullanmayın.

---

### 4.2 · Always-on dosyayı kesin

Kendi `copilot-instructions.md` dosyanıza Lab 1'deki testi uygulayın.
**Hedef: 500 token altı.**

| İçerik | JetBrains'te nereye |
|---|---|
| Spring Boot katman kuralları | `.prompt.md` — `/java-kurallari` |
| pandas/numpy kuralları | `.prompt.md` — `/python-kurallari` |
| Kod inceleme kontrol listesi | `.prompt.md` |
| Onboarding metni, takım tanıtımı | Wiki — model bunu okumuyor bile |
| Commit mesajı formatı | `.prompt.md` veya git hook |

**Tasarrufu paraya çevirin.** 120 kişi, günde 4 istek, 21 gün varsayımıyla:

| Kesilen | Aylık token | Dengeli model | Yıllık |
|---|---|---|---|
| 500 token | 5,04M | $10,08 | $121 |
| 1.000 token | 10,08M | $20,16 | $242 |
| 2.000 token | 20,16M | $40,32 | $484 |

> [!CAUTION]
> **Sahte sonucun işareti:** dosyayı küçülttünüz ama hiçbir satırı
> **taşımadıysanız**, muhtemelen gerçekten gerekli kuralları sildiniz.
> Kestiğiniz satırlar nereye gitti?

---

### 4.3 · Model yönlendirme tablonuzu yazın

| İş türü | Model sınıfı | Gerekçe |
|---|---|---|
| Satır içi tamamlama | varsayılan | Hiç ölçülmüyor |
| Basit soru, kod okuma | hafif | Muhakeme gerekmiyor |
| Hata ayıklama, refactor | dengeli | Günlük işin dürüst ortası |
| Mimari, karmaşık agent işi | güçlü | Fiyatını hak ediyor |
| Kod incelemesi | seçici | Koşu başına pahalı |

İyi bir tablonun üç özelliği:

- **Model adı değil, sınıf yazar** — model adları altı ayda değişir
- **İş türüne göre yazılır, kişiye göre değil**
- **Aşma yolunu tanımlar** — *"cevap yeterli değilse güçlü modele geç"*

İki karar daha verin:

| Soru | Cevabınız |
|---|---|
| Yeni sohbetin varsayılan modeli | |
| Yönlendirmeyi kim aşabilir | |

> [!CAUTION]
> **Bu tabloyu `copilot-instructions.md`'ye koymayın.** Günün en ironik hatası:
> maliyeti düşürmek için yazılan tablo, her isteğe eklenerek maliyeti artırır.
> Üstelik modelin karar vermediği bir şeyi modele anlatır. **Wiki'ye koyun.**

---

### 4.4 · Gerçek işte önce/sonra ölçün

Bu hafta gerçekten yaptığınız bir işi iki kez yapın.

- **Önce:** klasörün tamamı bağlamda, güçlü model, uzun sohbetin ortasında
- **Sonra:** yeni sohbet, sadece ilgili dosya, hafif model, net tek istek

| | Önce | Sonra |
|---|---|---|
| Kullanılan model | | |
| Bağlamdaki dosya sayısı | | |
| Harcanan kredi | | |
| Cevap kabul edilebilir mi? | | |

**Sahte sonucun üç işareti:**

1. Kalite satırı boş ya da gerekçesiz *"iyi"* yazıyor
2. *"Sonra"* koşusu farklı bir iş — kolay görevi hafif modele vermek ölçüm değil,
   seçim
3. Kredi düşüşü çok büyük ama iş yarım kalmış

<details>
<summary>Kalite düştüyse ne yapmalı</summary>

Sırayla deneyin:

1. Bağlamı aynı bırakın, **yalnızca modeli** yükseltin. Kalite dönüyor mu?
2. Model aynı kalsın, **yalnızca bir dosya** ekleyin. Kalite dönüyor mu?

Bu ikisini **ayrı ayrı** yapın. Aynı anda ikisini birden geri alırsanız
hangisinin gerektiğini asla öğrenemezsiniz — ve gereksiz olanı sonsuza kadar
ödersiniz.

</details>

---

### 4.5 · Eylem planınızı yazın

Tam üç satır:

| | Planınız |
|---|---|
| **Yarın** uygulayacağım kural | |
| **Bu çeyrekte** yapılacak değişiklik | |
| **Hâlâ ihtiyacım olan** veri | |

---

### Lab 4 çıktıları

- [ ] `.github` altındaki dosyalar tartıldı, kendi reponuz da ölçüldü
- [ ] Always-on dosya 500 token altına indirildi, tasarruf paraya çevrildi
- [ ] Model yönlendirme tablosu yazıldı — wiki'ye, repoya değil
- [ ] Önce/sonra ölçümü yapıldı, **kalite satırı dahil** dört satır dolu
- [ ] Üç satırlık eylem planı yazıldı

[↑ İçindekiler](#toc)

---

<a id="sorun"></a>

## Sorun giderme

### Kurulum

| Belirti | Sebep ve çözüm |
|---|---|
| `command not found: pip` | Sanal ortam aktif değil → `source .venv/bin/activate` |
| `externally-managed-environment` | Sistem Python'ına kurmaya çalışıyorsunuz → H8 |
| `python3 version` hatası | Komut `python3 --version`, iki tire |
| `No module named mcp` | Paketler yanlış ortama kuruldu → H8, H9 |

### Copilot

| Belirti | Sebep ve çözüm |
|---|---|
| Copilot ikonu gri | Oturum açılmamış → H4 |
| Sohbette araç çalışmıyor | Agent modunda değilsiniz → H5 |
| `/komut` listesi boş | Repo kökü açık değil → H7, sonra IDE'yi yeniden başlatın |
| Ayarlarda MCP bölümü yok | Eklenti eski → H2 |

### MCP

| Belirti | Sebep ve çözüm |
|---|---|
| Sunucu başlamıyor | `command` yanlış yorumlayıcı → 2.2 |
| Elle çalışıyor, IDE'de çalışmıyor | Yollarda `.venv` yok → H12, 2.2 |
| Kod değişti ama araç eski | Ayarlardan MCP'yi kaydedin veya IDE'yi yeniden başlatın |
| Kurumsal hesapta hiç görünmüyor | Yönetici politikası → H3 |

---

## Baştan sona kontrol

Hepsini tamamladıysanız elinizde şunlar olmalı:

- [ ] Çalışan bir kurulum: IntelliJ, Agent modu, bağlı MCP sunucusu
- [ ] Kendi gerçek kullanım rakamınız
- [ ] Kendi ekibinize kalibre edilmiş bir maliyet modeli
- [ ] Üç eşik, kendi terminalinizde doğrulanmış
- [ ] Kesilmiş bir always-on dosya ve parayla ifade edilmiş tasarrufu
- [ ] Bir model yönlendirme tablosu
- [ ] Kalite satırı dolu bir önce/sonra ölçümü
- [ ] Üç satırlık eylem planı

---

## IntelliJ'de neyin farklı olduğu

| Konu | VS Code | IntelliJ |
|---|---|---|
| `copilot-instructions.md` | Var | Var |
| `applyTo` ile kapsamlama | Var | **Yok** |
| Chat mode | Var | **Yok** — prompt dosyasıyla taklit |
| Prompt dosyaları | Var | Var, daha da önemli |
| MCP yapılandırması | Repoda `mcp.json` | **IDE ayarlarında** |
| Sunucu yeniden başlatma | `MCP: Restart Server` | Ayarları kaydet veya IDE'yi yeniden başlat |
| Token ekonomisi | — | **Tamamen aynı** |

JetBrains'e özel iki ek konu:

- **`global-copilot-instructions.md`** — makinede duran, tüm projelere uygulanan
  yerel talimat dosyası. Her isteğe giriyor ve kimse incelemiyor.
- **Uzak MCP sunucularında PAT gerekiyor** — JetBrains henüz OAuth
  desteklemiyor.

---

> [!NOTE]
> Bu kılavuzdaki maliyet rakamları modellenmiş kullanım varsayımlarına dayanıyor
> ve büyüklük mertebesi göstermek içindir. Model fiyatları değişiyor. Kendi
> gerçek rakamınız her zaman **GitHub → Settings → Billing → Usage**
> ekranındadır.
