# Lab 1 — Talimat dosyaları (IntelliJ)

**Süre:** 45 dakika
**Kimler:** herkes — geliştirici ve analist aynı uygulamayı yapar
**Hedef:** Copilot'un davranışını dosyayla yönetmek ve her dosyanın maliyet etkisini görmek

> **Bu dosya IntelliJ / JetBrains IDE'ler içindir.** VS Code kullanıyorsanız
> `labs/LAB-1-talimat-dosyalari.md` dosyasını açın. İki ortam arasındaki fark
> gerçek: JetBrains'te `applyTo` ile kapsamlama ve `.chatmode.md` desteklenmiyor.

---

## Başlamadan önce

Projeyi IntelliJ'de açın. Sağ alttaki **Copilot** ikonundan oturum açtığınızı ve
sohbet panelinin açıldığını doğrulayın (`Tools → GitHub Copilot → Open Chat`).

Sohbet panelinde **Agent** modunun seçili olduğunu kontrol edin. Ask modunda
araçlar çalışmaz; Lab 2'de buna ihtiyacınız olacak.

---

## Adım 1 — Önce ölçün (5 dk)

Hiçbir dosyaya bakmadan Copilot'a sorun:

```
Bu projede para tutarları için hangi tipi kullanmalıyım?
```

Cevabı olduğu gibi not edin. Genel bir şey alacaksınız — "BigDecimal genelde iyi
bir seçim ama duruma göre değişir" gibi — çünkü sizin kuralınızı bilmiyor.

> **Bu adım neden var:** talimat dosyasını önce eklerseniz farkı hiç
> göremezsiniz. Bugün yapacağınız her ölçümde bu sıra geçerli: önce ölç, sonra
> değiştir.

---

## Adım 2 — Kurum talimatını ekleyin (10 dk)

`.github/copilot-instructions.md` dosyasını açıp okuyun. Altı invariant var.

Sonra **aynı soruyu**, **yeni bir sohbette** tekrar sorun.

Artık kesin cevap gelmeli: `BigDecimal`, asla `double`.

> **Yeni sohbet şart.** Aynı sohbette sorarsanız ilk cevap hâlâ bağlamda durur
> ve ikincisi kirlenir. Lab 3'te aynı hata bütün ölçümünüzü bozar.

### Asıl uygulama

Dosyayı satır satır gezin ve her satır için şunu yanıtlayın:

> Ekibimin sorduğu soruların yüzde kaçında bu satır gerçekten gerekli?

| Soruların ne kadarında gerekli | Nereye ait |
|---|---|
| %80+ | `copilot-instructions.md`'de kalsın |
| %20–80 | Prompt dosyasına taşıyın (JetBrains'te `applyTo` yok) |
| %20'nin altı | Prompt dosyasına, istendiğinde çağrılsın |

Dosyayı tartın — IntelliJ'in terminalinden (`View → Tool Windows → Terminal`):

```bash
python -c "
import sys; sys.path.insert(0,'.')
from cost.calculator import estimate_tokens
from pathlib import Path
for f in sorted(Path('.github').rglob('*.md')):
    print(f'{estimate_tokens(f.read_text()):>6} token  {f}')
"
```

**Beklenen:** `copilot-instructions.md` yaklaşık 290 token. Kendi kurumunuzdaki
dosya büyük ihtimalle bunun üç ila on katı.

---

## Adım 3 — Kapsamlama neden yok, ne yapacaksınız (10 dk)

VS Code'da kapsamlı talimat dosyaları var: `.github/instructions/*.instructions.md`
dosyalarının başındaki `applyTo` globu sayesinde bir Java kuralı, siz Python
yazarken hiç yüklenmiyor.

**JetBrains'te bu desteklenmiyor.** Repo başına tek bir `copilot-instructions.md`
okunuyor. Dolayısıyla elinizde iki araç var:

| İhtiyaç | VS Code | JetBrains karşılığı |
|---|---|---|
| Her yerde geçerli kural | `copilot-instructions.md` | Aynı |
| Teknolojiye özgü kural | `*.instructions.md` + `applyTo` | **Yok** — prompt dosyasına taşıyın |
| Tekrarlanan görev | `*.prompt.md` | Aynı, `/` ile çağrılır |
| Farklı çalışma kipi | `*.chatmode.md` | **Yok** — prompt dosyasıyla taklit edilir |

### Uygulama

Repodaki `.github/instructions/java-service.instructions.md` dosyasını açın.
İçindeki kuralları okuyun ve şu soruyu yanıtlayın:

> Bu 310 token'lık içerik JetBrains'te nereye ait? Hepsi her isteğe mi girmeli,
> yoksa bir kısmı istendiğinde mi çağrılmalı?

Kararınızı bir cümleyle yazın. Lab 4'te bu kararı uygulayacaksınız.

> **Dikkat:** `instructions/` klasörü repoda duruyor ama JetBrains onu okumuyor.
> Yani orada duran içerik maliyet üretmiyor — ama kimseye de fayda sağlamıyor.
> Karma ekiplerde (bir kısmı VS Code, bir kısmı IntelliJ) bu önemli bir
> tutarsızlık kaynağı: aynı repo iki geliştiricide farklı davranıyor.

---

## Adım 4 — Prompt dosyaları (10 dk)

Bir `.java` dosyası açıkken sohbete yazın:

```
/service-review
```

**Beklenen:** eğik çizgiyi yazdığınızda açılan listede `service-review`,
`release-check` ve `analist` görünmeli.

Tek komut, her seferinde yeniden yazacağınız bir paragraf talimatın yerine
geçiyor.

### Kendi promptunuzu yazın

Haftada en az bir kez tekrarladığınız bir işi seçin. `.github/prompts/` altına
dosya oluşturun. Şu üçü mutlaka olsun:

1. **Birden fazla adım** — tek cümleyse zaten dosyaya ihtiyacınız yoktu.
2. **Açık çıktı biçimi** — hangi tablo kolonlarını veya başlıkları istiyorsanız yazın.
3. **Sonunda bir duruş** — "önce raporu ver, onay bekle".

Sohbete `/<isiniz>` yazarak test edin. Listede çıkmıyorsa IDE'yi yeniden başlatın.

> **JetBrains'te prompt dosyaları neden daha önemli:** `applyTo` ve chat mode
> olmadığı için, her istekte yüklenen dosyadan çıkardığınız her şeyin gideceği
> tek yer burası. VS Code'da üç seçenek vardı, burada iki.

---

## Adım 5 — Analist modu, prompt dosyası olarak (10 dk)

VS Code'da `.chatmode.md` ile kalıcı bir çalışma kipi tanımlanabiliyor — mod
seçildiği sürece asistan kod yazmayı reddediyor ve araç erişimi kısıtlanıyor.

**JetBrains'te chat mode yok.** Davranışı prompt dosyasıyla taklit ediyoruz.

`.github/prompts/analist.prompt.md` dosyasını açıp okuyun. Sonra sohbete:

```
/analist
```

Ardından sorun:

```
Sürüm takvimi kuralları nerede tanımlı ve ne diyor?
```

Sonra deneyin:

```
Bana bir servis sınıfı yaz.
```

**Beklenen:** ikincisini reddetmeli.

### İki farkı not edin

| | Chat mode (VS Code) | Prompt dosyası (JetBrains) |
|---|---|---|
| Ne kadar sürer | Mod seçili kaldığı sürece | O sohbet boyunca, zayıflayarak |
| Araç erişimi | `tools` alanıyla kısıtlanır | Kısıtlanamaz |
| Nasıl açılır | Mod menüsünden | `/analist` yazarak |

İkinci satır önemli: chat mode'da araç kısıtlaması bağlamı da küçültüyordu —
az araç, az şema, ucuz cevap. Prompt dosyasında bu kazanç yok. Davranışsal sınır
kalıyor, maliyet kazancı kalmıyor.

> **Analistler için:** bu mod size kod yazan değil **kod okuyan** bir asistan
> veriyor. Cevaplar iş diliyle ve `dosya:satır` referansıyla geliyor — o
> referansı bir mühendise verebilirsiniz.

---

## Çıktılar

- [ ] Adım 1 ve 2'deki iki cevap yazılı, farkı görüldü
- [ ] `copilot-instructions.md`'den en az bir satır tartışıldı
- [ ] Kapsamlama olmadığında ne yapılacağına dair karar yazıldı
- [ ] Kendi `.prompt.md` dosyanız, `/komut` ile test edildi
- [ ] `/analist` denendi, reddedişi görüldü

---

## Tartışma soruları

**1.** Kurumunuzda bu dosyaları kim yazar ve kim onaylar? Bir geliştirici
`copilot-instructions.md`'ye satır eklediğinde maliyet herkese yayılıyor.
Bu dosya kod mudur, politika mıdır?

**2.** Ekibinizde hem VS Code hem IntelliJ kullanılıyorsa aynı repo iki kişide
farklı davranıyor. Bunu nasıl yönetirsiniz — en küçük ortak paydada mı
buluşursunuz, yoksa her IDE için ayrı mı yazarsınız?
