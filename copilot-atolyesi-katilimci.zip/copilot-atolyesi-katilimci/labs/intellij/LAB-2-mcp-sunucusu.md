# Lab 2 — MCP sunucusu (IntelliJ)

**Süre:** 60 dakika
**Kimler:** herkes bağlar; ikinci yarıda iki kola ayrılıyoruz
**Hedef:** kurum içi bir kaynağı Copilot'a araç olarak açmak ve sınırlarını görmek

> **Bu dosya IntelliJ / JetBrains IDE'ler içindir.** En büyük fark burada:
> JetBrains MCP yapılandırmasını repodaki `.vscode/mcp.json` dosyasından değil,
> **Copilot ayar arayüzünden** okuyor.

---

## Adım 1 — Ortamı kurun (10 dk)

### 1a. Sanal ortam

IntelliJ'in terminalini açın (`View → Tool Windows → Terminal`):

```bash
python3 -m venv .venv
source .venv/bin/activate          # Windows: .venv\Scripts\activate
python -m pip install -r requirements.txt
python -m pytest tests -q          # beklenen: 28 passed
```

`pip install mcp` PyJWT çakışmasıyla patlarsa:

```bash
python -m pip install mcp --ignore-installed PyJWT
```

Komut isteminin başında `(.venv)` yazdığını görün.

### 1b. İki yolu alın ve bir yere kopyalayın

```bash
echo "KOMUT : $(pwd)/.venv/bin/python"
echo "ARGUMAN: $(pwd)/mcp_server/corp_server.py"
```

Windows'ta:

```
echo %CD%\.venv\Scripts\python.exe
echo %CD%\mcp_server\corp_server.py
```

**Bu iki satırı kopyalayın.** Birazdan ayar arayüzüne elle yazacaksınız —
JetBrains'te `${workspaceFolder}` gibi bir değişken yok, tam yol gerekiyor.

### 1c. Sunucuyu elle bir kez çalıştırın

IDE'ye geçmeden önce:

```bash
"$(pwd)/.venv/bin/python" "$(pwd)/mcp_server/corp_server.py"
```

**Beklenen:** hiçbir şey. Terminal donar ve bekler — bu doğru, sunucu stdin
dinliyor. `Ctrl+C` ile çıkın.

Traceback dökerse hata buradadır ve IDE'nin sizden saklayacağı şeyi burada
görüyorsunuz.

---

## Adım 2 — MCP'yi ayar arayüzünden tanımlayın (10 dk)

> **VS Code'dan en büyük fark bu adımda.** Orada repoda duran bir
> `.vscode/mcp.json` dosyası vardı ve ekiple paylaşılıyordu. JetBrains'te
> yapılandırma IDE ayarlarında duruyor.

1. Sağ alt köşedeki **Copilot ikonuna** tıklayın
2. **Edit Settings** seçin
3. **Model Context Protocol** bölümüne gidin
4. **Configure** düğmesine basın — bir `mcp.json` düzenleyicisi açılır

Açılan dosyaya şunu yazın, **yolları 1b'de kopyaladığınız değerlerle
değiştirerek**:

```json
{
  "servers": {
    "corp-internal": {
      "type": "stdio",
      "command": "/BURAYA/KOMUT/YOLU",
      "args": ["/BURAYA/ARGUMAN/YOLU"]
    }
  }
}
```

`Ctrl+S` / `Cmd+S` ile kaydedin veya dosyayı kapatın. Yapılandırma hemen
devreye girer; girmezse IDE'yi yeniden başlatın.

> **Düz `python` yazmayın.** PATH'te ilk gelen yorumlayıcı çalışır — genelde
> sistem Python'ı veya Anaconda base ortamı. Orada `mcp` paketi olmadığı için
> süreç anında ölür ve sebebi görünmez.

### Bunun üç sonucu

| | VS Code | JetBrains |
|---|---|---|
| Yapılandırma nerede | Repoda, `.vscode/mcp.json` | IDE ayarlarında |
| Ekiple paylaşılır mı | Evet, commit edilir | **Hayır**, her geliştirici kendi kurar |
| PR'da incelenir mi | Evet | **Hayır** |

Üçüncü satır bankada konuşulmaya değer: repoda duran bir yapılandırma
incelenebilir bir karardır. IDE ayarında duran yapılandırma, kimsenin görmediği
bir karardır.

---

## Adım 3 — Sunucuyu başlatın ve doğrulayın (10 dk)

Copilot sohbet panelini açın (`Tools → GitHub Copilot → Open Chat`) ve
**Agent** modunda olduğunuzu doğrulayın.

Sohbete yazın:

```
standards_list aracını çalıştır
```

**Beklenen:** araç çağrısı için bir **izin istemi**. İzin verdiğinizde üç
standardın listesi dönecek: `java-service`, `data-access`, `ai-assistant-usage`.

### Sorun giderme

| Belirti | Sebep ve çözüm |
|---|---|
| Araç bilinmiyor diyor | Agent modunda değilsiniz |
| Sunucu başlamıyor | `command` yanlış yorumlayıcı — 1b'ye dönün |
| Hiçbir şey olmuyor | IDE'yi tamamen kapatıp açın |
| Ayarlarda MCP bölümü yok | Copilot eklentisi eski; güncelleyin |
| Kurumsal hesapta MCP kapalı | Yönetici politikası — eğitmene söyleyin |

---

## Adım 4 — Üç soruyu sorun (10 dk)

Her birini **ayrı sohbette** sorun:

```
Hangi dahili API'ler kişisel veri içermiyor?
```

```
Bugün üretime çıkabilir miyiz?
```

```
14 Ağustos 2026'da deploy edebilir miyiz?
```

**Beklenen:** üçüncüsü **hayır** demeli ve gerekçesini de vermeli —
"Month-end reconciliation window".

> **Buradaki asıl ders:** araç sadece `false` döndürmüyor, nedenini de
> döndürüyor. Model gerekçeyi uyduramıyor, alıntılamak zorunda.
>
> Her çağrıdan önce gelen izin istemini okuyun. O istem bu labın ana konusu:
> her araç çağrısı, bir insanın belirli bir anda verdiği bir karar. Denetim
> izini anlamlı kılan şey o.

---

## Adım 5 — Kendi kolunuzu yapın (15 dk)

### Geliştirici kolu

`mcp_server/corp_server.py` dosyasında `tool_cost` fonksiyonunun **üstüne**
yeni bir araç ekleyin:

```python
@mcp.tool()
def find_service_owner(service_name: str) -> str:
    """Bir servisten sorumlu ekibi döndürür.

    Kullanıcının bir servis hakkında kime başvuracağını bilmesi gerektiğinde
    kullan — kayıt açmadan veya olayı yükseltmeden önce. Elinde yalnızca
    kısmi bir isim varsa önce api_search çağır.

    Args:
        service_name: API kataloğundaki anahtar veya ad.
    """
    # gövdeyi siz yazın
```

Üç kural:

- Docstring "**ne zaman çağrılacağını**" söylesin, "ne yaptığını" değil
- Bulunamayınca **mevcut seçenekleri döndürün**
- Kişisel veri döndürmeyin

`tests/test_mcp_tools.py` dosyasına testini yazın — import satırına
`find_service_owner` eklemeyi unutmayın:

```python
def test_find_service_owner_returns_the_team():
    result = call(find_service_owner, service_name="limit-engine")
    assert result["owner_team"] == "Credit Technology"


def test_unknown_service_lists_alternatives():
    result = call(find_service_owner, service_name="nope")
    assert "error" in result
    assert "limit-engine" in result["available"]
```

```bash
python -m pytest tests -q
```

**Beklenen:** `30 passed`

Sonra sunucuyu yeniden yükleyin. JetBrains'te **MCP: Restart Server** komutu
yok — Copilot ayarlarından MCP yapılandırmasını açıp kaydedin, ya da IDE'yi
yeniden başlatın. Ardından sorun: *Limit motorunun sahibi kim?*

### Analist kolu

Araç yazmıyorsunuz. Daha zor olan soruyu yanıtlıyorsunuz: **hangi araç
olmamalı.**

`mcp_server/corp_server.py` dosyasını açın, beş docstring'i okuyun ve dört
soruya **yazılı** cevap verin:

1. Hangi açıklama modelin **yanlış aracı** seçmesine yol açabilir? Yeniden yazın.
2. `api_search` aracının `pii_free_only` parametresi olmasaydı ne bozulurdu?
3. Bu sunucuya **eklenmemesi** gereken bir araç söyleyin ve nedenini savunun.
   Somut olun: hangi veriyi döndüreceğini ve neyin ters gideceğini adıyla yazın.
4. `can_deploy` verdiktin yanında gerekçe de döndürüyor. Sadece `true`/`false`
   dönseydi ne kaybederdik?

**JetBrains'e özel beşinci soru:**

5. Yapılandırma repoda değil IDE ayarlarında duruyor. Bir denetçi "bu ekip hangi
   MCP sunucularını bağlamış?" diye sorsa, cevabı nereden bulursunuz?

Değerlendirmede **ilk siz sunuyorsunuz.** İki dakika.

---

## Adım 6 — Sunucunun maliyetini görün (5 dk)

```
tool_cost aracını çalıştır
```

Her aracın yaklaşık token sayısını ve toplamı göreceksiniz. Bu şemalar, **bu
sunucu bağlıyken yapılan her isteğe** gidiyor — sunucuyla hiç ilgisi olmayan
istekler dahil.

Hesabı sesli yapın: sekizer araçlı on sunucu, sorduğunuz **her sorunun** başına
seksen araç şeması ekler. Copilot'un tavanı istek başına 128 araç, ama kalite
bozulması çok daha önce başlar.

**Kural:** bugün kullanmadığınız sunucuyu kapatın.

---

## Çıktılar

- [ ] Sunucu ayar arayüzünden tanımlandı, tam yollarla
- [ ] Elle çalıştırıldı ve dondu
- [ ] Üç soru soruldu, üçüncüsü gerekçeli hayır döndü
- [ ] Geliştirici: `find_service_owner` yazıldı, `30 passed`, canlı çalışıyor
- [ ] Analist: beş soruya yazılı cevap
- [ ] `tool_cost` çalıştırıldı, hesap yapıldı

---

## Tartışma soruları

**1.** Bu sunucu bilinçli olarak müşteri verisi döndürmüyor. Bir ekip müşteri
sorgulama aracı yazmak isterse hangi onaylardan geçmeli — ve kararı kim verir?

**2.** Yapılandırma IDE ayarlarında durduğu için ekip genelinde görünür değil.
Onaylı sunucu listesini nasıl uygularsınız — merkezî bir politikayla mı, yoksa
güvene mi dayanırsınız?
