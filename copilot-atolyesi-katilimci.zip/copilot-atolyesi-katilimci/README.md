# Copilot, MCP ve Token Ekonomisi

**Bir günlük atölye · katılımcı materyali**

> Bağlam bir bütçedir. Ne gönderdiğiniz, neyi açtığınız, ne ödediğiniz.

Modele gönderdiğiniz her şey — talimat dosyalarınız, açtığınız MCP araçları,
sohbet geçmişiniz — her istekte yeniden gönderiliyor ve her istekte yeniden
faturalanıyor. 1 Haziran 2026'daki kullanım bazlı faturalama geçişiyle bu artık
bir benzetme değil.

Bu repo atölyenin dört labını yürütmek için gereken her şeyi içeriyor: çalışan
bir MCP sunucusu, bir maliyet hesaplayıcısı ve adım adım kılavuzlar.

---

## Nereden başlamalı

**IDE'nize göre bir kılavuz seçin ve baştan sona izleyin.** Her ikisi de boş bir
makineden dört labın sonuna kadar tek akış hâlinde ilerliyor.

| Kullandığınız IDE | Kılavuz |
|---|---|
| **VS Code** | [`SIFIRDAN-YAPMA-KILAVUZU.md`](SIFIRDAN-YAPMA-KILAVUZU.md) |
| **IntelliJ / JetBrains** | [`labs/intellij/SIFIRDAN-YAPMA-KILAVUZU.md`](labs/intellij/SIFIRDAN-YAPMA-KILAVUZU.md) |

Her adımda üç şey var: ne yaptığınız, çalıştıracağınız komut ve **görmeniz
gereken çıktı**. Gördüğünüz çıktı yazandan farklıysa devam etmeyin, o adımda
kalın.

---

## Hızlı başlangıç

```bash
python3 -m venv .venv
source .venv/bin/activate            # Windows: .venv\Scripts\activate
python -m pip install -r requirements.txt

python -m pytest tests -q            # 28 passed
python cost/scenarios.py             # önce/sonra maliyet tablosu
```

MCP sunucusunu bağlamadan önce yorumlayıcının **tam yolunu** öğrenin:

```bash
which python                         # Windows: where python
```

> [!CAUTION]
> Yapılandırmaya düz `python` yazarsanız PATH'teki ilk yorumlayıcı çalışır,
> `mcp` paketi orada olmadığı için süreç sessizce ölür ve **sebebi görünmez**.
> Tam yol yazın.

Kurulumun geri kalanı IDE'nize göre değişiyor — kılavuzu izleyin.

---

## Ön koşullar

| | |
|---|---|
| **IDE** | VS Code veya IntelliJ IDEA (kararlı sürüm) + GitHub Copilot eklentisi |
| **Hesap** | Copilot Business, Enterprise veya Free |
| **Python** | 3.10 veya üstü |

Kurumsal planda iki şeyin açık olması gerekir ve ikisi de yönetici işi: **Agent
modu izni** ve **MCP sunucu izni**. İkincisi varsayılan olarak kapalı olabilir —
kapalıyken MCP yapılandırması hiçbir şey yapmaz, hata da vermez.

---

## Dört lab

| # | Lab | Süre | Konu |
|---|---|---|---|
| 1 | Talimat dosyaları | 45 dk | Hangi kural hangi dosyaya, maliyet etkisi |
| 2 | MCP sunucusu | 60 dk | Kurum içi kaynağı araç olarak açmak, sınırları |
| 3 | Ölçüm | 45 dk | Kendi rakamınızı bulmak, üç eşiği doğrulamak |
| 4 | Optimizasyon | 60 dk | Yedi kaldıraç, önce/sonra ölçüm |

Lab dosyaları `labs/` altında. IntelliJ kullanıyorsanız Lab 1 ve Lab 2 için
`labs/intellij/` sürümlerini kullanın — o IDE'de `applyTo` ve chat mode
desteklenmiyor, MCP de farklı yerden yapılandırılıyor.

İngilizce lab sürümleri `labs/en/` altında.

### Üç eşik

| Eşik | Kat | Ne yapılır |
|---|---|---|
| Model seçimi | **25×** | Rutin işi hafif modele yönlendir |
| Önbellek | **10×** | Bağlamın sabit kısmını sabit tut |
| Uzun bağlam (272K) | **2×** | Tüm repoyu bağlama atma |

Kaldıraçlar toplanmıyor, **çarpılıyor**. Lab 3'te bunu kendiniz göreceksiniz:
sadece model 25×, sadece bağlam 9×, ikisi birden **224×**.

---

## Belgeler

| Belge | Ne için |
|---|---|
| [`Copilot-Atolyesi-Lab-Kilavuzu.pdf`](Copilot-Atolyesi-Lab-Kilavuzu.pdf) | Dört labın basılabilir hâli, doldurulacak alanlarla |
| [`Copilot-Atolyesi-Ders-Notlari.pdf`](Copilot-Atolyesi-Ders-Notlari.pdf) | Anlatım bölümlerinin kalıcı hâli, kavram sözlüğü ve referans kartı |

---

## Repo içeriği

```
.github/
  copilot-instructions.md            her istekte yüklenir · ~290 token
  instructions/*.instructions.md     applyTo ile kapsamlanmış (VS Code)
  prompts/*.prompt.md                /komut ile çağrılır
  chatmodes/analyst.chatmode.md      analist modu (VS Code)
.vscode/mcp.json                     MCP sunucu tanımı (VS Code)
mcp_server/corp_server.py            5 araç · kişisel veri yok
cost/
  calculator.py                      fiyat tablosu + maliyet motoru
  scenarios.py                       önce/sonra senaryo karşılaştırması
labs/                                dört lab (TR) · en/ (EN) · intellij/ (JetBrains)
tests/                               28 test · çevrimdışı
```

### MCP sunucusu bilerek müşteri verisi döndürmüyor

Bankaya MCP sunucusu yazarken ilk akla gelen fikir genelde yanlış olanıdır.
Müşteri 360 teknik olarak kolaydır ve kişisel veriyi, binadan çıkan bir bağlam
penceresine koyar.

Bu sunucu bunun yerine mühendislik standartlarını, dahili API kataloğunu ve
sürüm takvimini açıyor. Katalog bir servisin kişisel veri **içerdiğini söyler** —
verinin kendisini vermez. Hassas verinin nerede olduğunu tarif etmek, onu
taşımaktan farklı bir eylemdir.

Bu kural bir testle korunuyor: `test_no_tool_returns_personal_data`.

---

## Notlar

> [!NOTE]
> Bu materyaldeki maliyet senaryoları **modellenmiş kullanım varsayımlarına**
> dayanıyor; kanıt değil, büyüklük mertebesi göstergesi. Kendi gerçek rakamınız
> her zaman **GitHub → Settings → Billing → Usage** ekranındadır.
>
> Model fiyatları değişiyor. Kendi kurumunuz için hesap yaparken güncel fiyat
> tablosunu [GitHub Docs](https://docs.github.com/en/copilot/reference/copilot-billing/models-and-pricing)
> üzerinden doğrulayın.

Repo çevrimdışı çalışır: API anahtarı gerekmez, ağ erişimi gerekmez, 28 test
geçer.
