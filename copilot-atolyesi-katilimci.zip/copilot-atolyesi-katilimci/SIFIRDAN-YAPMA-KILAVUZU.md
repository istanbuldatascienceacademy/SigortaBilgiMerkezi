# Sıfırdan yapma kılavuzu

Boş bir makineden başlayıp dört labın sonuna kadar, her adım tek tek.

**Kim için:** provaya çıkan eğitmen ve tek başına ilerleyen katılımcı. İkisi de
aynı yolu izler.

**Nasıl kullanılır:** sırayla git, atlama. Her adımda üç şey var — ne yaptığın,
çalıştıracağın komut, ve **görmen gereken çıktı**. Gördüğün çıktı yazandan
farklıysa devam etme, o adımda kal.

**Eğitmensen:** her bölümün başındaki süreyi not al. Yazan süreler benim
tahminim; senin ölçtüğün rakam gün içinde tempo tutmanı sağlar.

---

# BÖLÜM 0 — Sıfır noktası

**Süre:** 20–30 dakika · **Ne zaman:** eğitimden önce, tek başına

Bu bölüm labların parçası değil. Labların çalışması için gereken zemin.

---

## 0.1 — Python var mı?

**Ne yapıyorsun:** makinede kullanılabilir bir Python olup olmadığına bakıyorsun.

```bash
python3 --version
```

**Görmen gereken:**

```
Python 3.12.3
```

Sürüm **3.10 veya üstü** olmalı.

**Dikkat:** komut `python3 --version` — iki tire, aralarında boşluk yok. `python3
version` yazarsan Python `version` adlı bir dosya arar ve `No such file or
directory` der.

**"command not found" diyorsa:** Python kurulu değil.
[python.org/downloads](https://python.org/downloads) adresinden kurun. Mac'te
Homebrew varsa `brew install python@3.12` de olur. Kurduktan sonra **yeni bir
terminal açın** ve komutu tekrarlayın.

**Sürüm 3.10'un altındaysa:** güncel bir sürüm kurun. `mcp` paketi 3.10+ istiyor
ve Lab 2 çalışmaz.

---

## 0.2 — VS Code kur

**Ne yapıyorsun:** editörü kuruyorsun.

[code.visualstudio.com/download](https://code.visualstudio.com/download)
adresinden indir.

**Mac kullanıcıları için:** Apple Silicon mı Intel mi emin değilsen:

```bash
uname -m
```

`arm64` → Apple Silicon. `x86_64` → Intel.

**Kararlı sürümü kur, Insiders değil.** İkisi de kurulabilir ve yan yana durur:
mavi ikon kararlı, yeşil ikon Insiders. Insiders'ta arayüz haftalık değişiyor;
eğitimde katılımcılar kararlı sürüm kullanacak, senin de aynısını görmen lazım.

Kurduktan sonra doğrula: `Code → About Visual Studio Code`. Başlıkta "Insiders"
kelimesi **geçmemeli**.

---

## 0.3 — Copilot hesabı

**Ne yapıyorsun:** GitHub hesabına Copilot erişimi bağlıyorsun.

Tarayıcıda [github.com/settings/copilot](https://github.com/settings/copilot)
adresini aç.

**Görmen gereken:** aktif bir plan. Yoksa Copilot Free'yi etkinleştir.

**Not:** Copilot Pro, Pro+, Max ve Student planlarına yeni kayıtlar şu an
duraklatılmış durumda. Free planı prova için yeterli — sadece Lab 3'te göreceğin
kredi rakamı küçük olur.

**Kurumsal koltuk kullanıyorsan** bu ekran farklı görünür ve iki şeyin açık
olması gerekir. İkisi de yönetici işi:

- Agent modu izni
- **"MCP servers in Copilot"** politikası — varsayılan **kapalı**

İkincisi kapalıysa `.vscode/mcp.json` hiçbir şey yapmaz. Sunucu görünmez, hata da
vermez. Eğitimden önce isim vererek teyit ettir.

---

## 0.4 — VS Code'da oturum aç

**Ne yapıyorsun:** editörü GitHub hesabına bağlıyorsun.

1. VS Code'u aç
2. Sol alt köşede, dişli ikonunun hemen **üstündeki** kişi ikonuna tıkla
3. **Sign in with GitHub** seç
4. Tarayıcı açılır, yetkilendir, VS Code'a dön

**Görmen gereken:** aynı kişi ikonuna tekrar tıkladığında GitHub hesabın listede.

**Sol altta "Copilot" yazısı arama** — öyle bir yazı yok. Orada sadece ikonlar
var.

**Kurumsal ağdaysan** oturum açma burada takılabilir. Ağ ekibiyle `github.com` ve
`api.githubcopilot.com` erişimini teyit et.

---

## 0.5 — Agent modunu aç

**Ne yapıyorsun:** ayarın açık olduğunu doğruluyorsun.

1. `Cmd+,` (Windows/Linux: `Ctrl+,`) ile ayarları aç
2. Arama kutusuna `chat.agent.enabled` yaz

**Görmen gereken:** işaretli bir kutu. Değilse işaretle.

**Bulamazsan:** eski kaynaklarda geçen `github.copilot.chat.agent.enabled` artık
kullanılmıyor, onu arama.

**Ayar gri ve kilitliyse:** kurumsal politika kapatmış. 0.3'teki yönetici adımına
dön.

---

## 0.6 — Sohbet panelini aç

**Ne yapıyorsun:** panelin çalıştığını görüyorsun.

`Ctrl+Cmd+I` (Windows/Linux: `Ctrl+Alt+I`).

Çalışmazsa: `Cmd+Shift+P` → `Chat: Focus on Chat View` yaz ve seç.

**Görmen gereken:** sağda açılan bir panel, altında bir giriş kutusu, kutunun
çevresinde birkaç açılır kontrol.

**Panel hiç açılmıyorsa:** Extensions panelinden (sol kenardaki kare bloklar
ikonu) `GitHub Copilot` ara ve kurulu olduğunu doğrula.

---

## 0.7 — Oturum kontrollerini ayarla

**Ne yapıyorsun:** dört kontrolü doğru konuma getiriyorsun. Bunlar giriş
kutusunun altında.

| Kontrol | Seçilecek | Neden |
|---|---|---|
| Session target | **Copilot** | Başka hedeflerin araçları ve yapılandırması farklı |
| Rol | **Agent** | Plan sadece tartışır, dosya değiştirmez; araçlar da çalışmaz |
| Model | **Auto** | Lab 3'e kadar önemli değil |
| Permissions | **Manual** | Lab 2'nin tüm anlatısı izin isteminin üzerine kurulu |

**Sonuncusu eğitim için kritik.** "Allow all" seçersen her araç çağrısı sessizce
geçer ve Lab 2'nin ana dersi — o istemin denetim izi olduğu — görünmez olur.

Sende bu kontroller farklı isimlerle görünebilir; sürüme göre değişiyor. Önemli
olan rolün **Agent**, izinlerin **manuel** olması.

---

## 0.8 — Temel doğrulama (MCP'siz)

**Ne yapıyorsun:** MCP'ye geçmeden önce temelin çalıştığını görüyorsun.

Herhangi bir klasör aç, herhangi bir dosyayı seç ve sohbete yaz:

```
Bu dosyanın ne yaptığını iki cümleyle anlat.
```

**Görmen gereken:** dosyayı okuduğunu belli eden bir cevap.

**Bu adımı atlama.** Buraya kadar çalışıyorsa temel kurulum tamamdır. Sonra bir
sorun çıkarsa nerede olmadığını bilirsin.

---

## 0.9 — Atölye reposunu aç

**Ne yapıyorsun:** materyali makineye indiriyorsun.

Repo sana **zip olarak** geldiyse indirdiğin yerde aç. Bir git deposuna
konulduysa:

```bash
git clone <BURAYA-GERCEK-ADRES>
```

**Not:** lab metinlerindeki `<atolye-repo>` bir yer tutucu, gerçek adres değil.
Eğitmenin sana vereceği adresle değiştir.

Sonra klasöre gir ve içeriği doğrula:

```bash
cd workshop
ls -a
```

**Görmen gereken:**

```
.github    .vscode    cost    labs    mcp_server    requirements.txt    tests
```

**`.github` ve `.vscode` görünmüyorsa** ya `ls -a` yerine `ls` yazdın (gizli
klasörler görünmez) ya da zip açılırken atlandı. `ls -a` ile tekrar bak.

---

## 0.10 — Sanal ortam kur

**Ne yapıyorsun:** paketleri sistem Python'ına değil, projeye özel bir ortama
kuruyorsun.

```bash
python3 -m venv .venv
source .venv/bin/activate
```

Windows'ta ikinci satır: `.venv\Scripts\activate`

**Görmen gereken:** komut isteminin başında `(.venv)`.

**Neden venv?** Sistem Python'ına kurmak iki şekilde patlıyor. macOS'ta Homebrew
Python'ı izin vermiyor:

```
error: externally-managed-environment
```

Anaconda kuruluysa paketler yanlış ortama gidiyor ve `mcp.json` yanlış
yorumlayıcıyı çalıştırıyor.

**Uyarı:** `(.venv)` yeni terminal açtığında kaybolur. Her yeni terminalde
`source .venv/bin/activate` çalıştır. `command not found: pip` hatası alıyorsan
sebebi budur.

---

## 0.11 — Paketleri kur

```bash
python -m pip install -r requirements.txt
```

`pip` değil `python -m pip` kullan — böylece kesinlikle aktif ortamın pip'i
çalışır.

**PyJWT çakışması çıkarsa:**

```bash
python -m pip install mcp --ignore-installed PyJWT
```

**Doğrula:**

```bash
python -c "import mcp, pytest; print('paketler tamam')"
```

**Görmen gereken:** `paketler tamam`

---

## 0.12 — Testleri çalıştır

**Ne yapıyorsun:** her şeyin yerli yerinde olduğunu kanıtlıyorsun.

```bash
python -m pytest tests -q
```

**Görmen gereken:**

```
............................                          [100%]
28 passed in 0.77s
```

**28 passed görmeden devam etme.** Sonraki her şey bunun üstüne kurulu.

---

## 0.13 — Klasörü VS Code'da aç

**Ne yapıyorsun:** editörü doğru klasöre getiriyorsun. Bu adım göründüğünden
önemli.

1. VS Code'da `File → Open Folder`
2. **Repo kökünü** seç — yani `.github` ve `.vscode` klasörlerini **içeren**
   dizini, bir üstünü değil
3. Güven sorusu çıkarsa **Yes, I trust the authors**

**Güvenilmeyen klasörde MCP sunucuları hiç listelenmez ve hata da verilmez.**

**Doğrula:** VS Code'un **entegre** terminalini aç (`Ctrl+ö` veya
`Terminal → New Terminal`) ve:

```bash
pwd
ls -a .vscode
```

**Görmen gereken:** `pwd` çıktısı repo kökü, ve `.vscode` içinde `mcp.json`.

Entegre terminal, VS Code'un açık olduğu klasörde başlar. Yani bu komut sana
doğrudan **VS Code'un nerede olduğunu** söyler — dışarıdaki bir terminalden
bakarak bunu anlayamazsın.

---

# BÖLÜM 1 — Lab 1: Talimat dosyaları

**Süre:** 45 dakika · **Gereken:** Bölüm 0 tamamlanmış

**Hedef:** Copilot'un davranışını dosyayla yönetmek ve her dosyanın maliyet
etkisini görmek.

---

## 1.1 — Önce ölç

**Ne yapıyorsun:** hiçbir dosyaya bakmadan, mevcut davranışı kaydediyorsun.

Sohbete yaz:

```
Bu projede para tutarları için hangi tipi kullanmalıyım?
```

**Görmen gereken:** genel bir cevap. "BigDecimal genelde iyi bir seçim ama duruma
göre değişir" gibi.

**Cevabı bir yere yaz.** Birazdan karşılaştıracaksın.

**Neden bu adım var:** talimat dosyasını önce eklersen farkı hiç göremezsin.
Bugün yapacağın her ölçümde bu sıra geçerli — önce ölç, sonra değiştir.

---

## 1.2 — Talimat dosyasını oku

**Ne yapıyorsun:** always-on dosyanın içeriğine bakıyorsun.

VS Code'da `.github/copilot-instructions.md` dosyasını aç.

**Görmen gereken:** altı invariant. BigDecimal, loglarda kimlik yok, parametreli
SQL, zaman aşımı, sırlar kodda değil, ve "bilmiyorsan sor".

---

## 1.3 — Aynı soruyu tekrar sor

**Ne yapıyorsun:** farkı ölçüyorsun.

**Yeni bir sohbet aç** ve birebir aynı soruyu sor.

**Görmen gereken:** kesin bir cevap. `BigDecimal`, asla `double`.

**Yeni sohbet şart.** Aynı sohbette sorarsan ilk cevap hâlâ bağlamda durur ve
ikincisi kirlenir. Bu, Lab 3'te bütün ölçümünü bozacak bir alışkanlık — şimdi
kur.

---

## 1.4 — Dosyayı tart

**Ne yapıyorsun:** her dosyanın kaç token ettiğini ölçüyorsun.

Terminalde:

```bash
python -c "
import sys; sys.path.insert(0,'.')
from cost.calculator import estimate_tokens
from pathlib import Path
for f in sorted(Path('.github').rglob('*.md')):
    print(f'{estimate_tokens(f.read_text()):>6} token  {f}')
"
```

**Görmen gereken:**

```
   279 token  .github/chatmodes/analyst.chatmode.md
   292 token  .github/copilot-instructions.md
   130 token  .github/instructions/data-jobs.instructions.md
   310 token  .github/instructions/java-service.instructions.md
   188 token  .github/prompts/release-check.prompt.md
   221 token  .github/prompts/service-review.prompt.md
```

Always-on dosya 292 token. Hedef 500'ün altı, yani rahatız.

**Şimdi asıl uygulama:** dosyayı satır satır gez ve her satır için sor —
*ekibimin sorduğu soruların yüzde kaçında bu satır gerçekten gerekli?*

| Oran | Nereye |
|---|---|
| %80+ | burada kalır |
| %20–80 | `instructions/` + `applyTo` |
| %20 altı | `.prompt.md`, istendiğinde çağrılır |

Kendi kurumunun dosyası varsa onu da aynı komutla ölç. Çoğu kurumda rakam üç ila
on kat büyük çıkar.

---

## 1.5 — applyTo farkını gör

**Ne yapıyorsun:** kapsamlı dosyanın gerçekten kapsamlı olduğunu kanıtlıyorsun.

Önce dosyayı aç: `.github/instructions/java-service.instructions.md`. Baştaki
frontmatter'da `applyTo: "**/*.java"` yazıyor.

Şimdi iki test:

**Test 1:** herhangi bir `.py` dosyası aç. **Yeni sohbette** sor:

```
Buradaki katman kuralları neler?
```

**Test 2:** herhangi bir `.java` dosyası aç. **Başka bir yeni sohbette** aynı
soruyu sor.

**Görmen gereken:** ikinci cevap Controller/Service/Repository katmanlarından
bahsediyor, birincisi bahsetmiyor.

Repoda `.java` dosyası yoksa boş bir tane oluştur:

```bash
mkdir -p ornek && echo "public class Test {}" > ornek/Test.java
```

---

## 1.6 — Prompt dosyasını dene

**Ne yapıyorsun:** hazır bir komutu çalıştırıyorsun.

Bir `.java` dosyası açıkken sohbete yaz:

```
/service-review
```

**Görmen gereken:** eğik çizgiyi yazdığında açılan listede `service-review` ve
`release-check` görünmeli.

**Liste çıkmıyorsa:** `.github/prompts/` klasörünün olduğunu ve VS Code'un repo
kökünü açtığını doğrula (Adım 0.13).

---

## 1.7 — Kendi prompt dosyanı yaz

**Ne yapıyorsun:** haftada tekrarladığın bir işi komuta çeviriyorsun.

`.github/prompts/` altına yeni bir dosya oluştur. Örneğin
`pr-aciklama.prompt.md`:

```markdown
---
description: Değişiklikler için PR açıklaması yazar
mode: agent
---

# PR açıklaması

1. Değişen dosyaları incele.
2. Şu başlıklarla bir açıklama yaz:
   - Ne değişti (madde madde)
   - Neden
   - Nasıl test edildi
3. Kod değiştirme. Sadece metni ver.
```

Üç kurala dikkat: çok adımlı, açık çıktı biçimi, sonunda bir duruş.

**Dene:** sohbete `/pr-aciklama` yaz.

**Dosya listede çıkmıyorsa:** `Cmd+Shift+P` → `Developer: Reload Window`.

---

## 1.8 — Analist modunu dene

**Ne yapıyorsun:** kod yazmayan bir asistanın nasıl davrandığını görüyorsun.

`.github/chatmodes/analyst.chatmode.md` dosyasını aç ve oku.

Şimdi sohbet giriş kutusunun altındaki **rol seçicisine** git — Agent'ı
seçtiğin menü. Listede `analyst` görünmeli.

**Görünmüyorsa:**

```bash
ls -la .github/chatmodes/
```

Dosya orada ama menüde yoksa: `Cmd+Shift+P` → `Developer: Reload Window`.

**Modu seçtikten sonra iki şey sor:**

```
Sürüm takvimi kuralları nerede tanımlı ve ne diyor?
```

```
Bana bir servis sınıfı yaz.
```

**Görmen gereken:** ikincisini **reddetmeli** ve Agent moduna geçmen gerektiğini
söylemeli.

Eğitmensen bunu sınıfta canlı göster. Sınırını tutan bir mod, anlattığın bir
moddan çok daha ikna edici.

---

## Lab 1 kontrol listesi

- [ ] 1.1 ve 1.3'teki iki cevap yazılı, farkı görüldü
- [ ] Token ölçümü çalıştırıldı, always-on dosya 292 token
- [ ] `applyTo` farkı `.py` ve `.java` ile canlı gözlendi
- [ ] Kendi `.prompt.md` dosyan yazıldı ve `/komut` ile çalıştı
- [ ] Analist modu denendi, reddedişi görüldü

**Takıldığın adımı ve süreyi not al.** Eğitmensen bu notlar metni düzeltmek için
en değerli veri.

---

# BÖLÜM 2 — Lab 2: MCP sunucusu

**Süre:** 60 dakika · **Gereken:** Bölüm 0 ve Lab 1 tamamlanmış

**Hedef:** kurum içi bir kaynağı Copilot'a araç olarak açmak ve sınırlarını
görmek.

> Bu labın ilk dört adımı kurulum. **Aceleye getirme.** Sahada en çok vakit
> kaybettiren yer burası ve sebebi neredeyse her zaman aynı: yanlış yorumlayıcı.

---

## 2.1 — mcp.json'ı doğru yaz

**Ne yapıyorsun:** VS Code'a sunucuyu hangi Python'la başlatacağını
söylüyorsun.

Repodaki `.vscode/mcp.json` dosyasında `"command": "python"` yazıyor ve bu
**yanlış**. Elle düzeltmek yerine şu bloğu olduğu gibi yapıştır — doğru yolları
kendisi bulur:

```bash
python - <<'EOF'
import json, sys, pathlib
kok = pathlib.Path.cwd()
cfg = kok / ".vscode" / "mcp.json"
cfg.parent.mkdir(exist_ok=True)
cfg.write_text(json.dumps({"servers": {"corp-internal": {
    "type": "stdio", "command": sys.executable,
    "args": [str(kok / "mcp_server" / "corp_server.py")]}}}, indent=2))
print(cfg.read_text())
EOF
```

**Görmen gereken:**

```json
{
  "servers": {
    "corp-internal": {
      "type": "stdio",
      "command": "/Users/adin/.../workshop/.venv/bin/python",
      "args": [
        "/Users/adin/.../workshop/mcp_server/corp_server.py"
      ]
    }
  }
}
```

**İki yolun da `.venv` içerdiğini gör.** İçermiyorsa sanal ortam aktif değil —
`source .venv/bin/activate` çalıştırıp bloğu tekrarla.

**Neden bu kadar önemli:** düz `python` PATH'te ilk gelen yorumlayıcıyı
çalıştırır. Genelde sistem Python'ı veya Anaconda base ortamı olur. Orada `mcp`
paketi yoktur, süreç anında ölür — ve VS Code hata gösterirken **output kanalı
boş kalır**, çünkü süreç bir şey yazacak kadar bile yaşamamıştır. Sebebi
görünmeyen bir hata alırsın.

---

## 2.2 — Sunucuyu elle çalıştır

**Ne yapıyorsun:** VS Code'a geçmeden önce sunucunun çalıştığını kanıtlıyorsun.

Yolu elle yazma, bunu yapıştır:

```bash
"$(pwd)/.venv/bin/python" "$(pwd)/mcp_server/corp_server.py"
```

**Görmen gereken:** hiçbir şey. Terminal donar ve bekler. **Bu doğru** — sunucu
stdin dinliyor. `Ctrl+C` ile çık.

**Traceback dökerse:** hata sunucu kodunda ya da kurulumda. Mesajı oku; VS
Code'un senden saklayacağı şeyi burada görüyorsun.

**Hemen komut istemine dönerse** (donmadan, hata da vermeden): komutu gerçek bir
terminalde çalıştırdığından emin ol. VS Code'un "Run Python File" düğmesiyle ya
da bir script içinden çalıştırırsan stdin kapalı olur ve sunucu sessizce çıkar.
Bu bir hata değil, ama bu adımın sana bir şey kanıtlamasını da engeller.

**`no such file or directory` diyorsa:** ya repo kökünde değilsin (`pwd` ile bak)
ya da `.venv` kurulmamış (`ls -d .venv`).

---

## 2.3 — VS Code'da başlat

**Ne yapıyorsun:** sunucuyu editöre tanıtıyorsun.

1. VS Code'u **tamamen kapat** — `Cmd+Q` (Windows: `Alt+F4`). Sadece pencereyi
   kapatmak yetmez.
2. Yeniden aç, `File → Open Folder` ile repo kökünü seç
3. Güven sorusuna **Yes, I trust the authors**
4. `Cmd+Shift+P` → **MCP: List Servers**
5. `corp-internal` → **Start Server**

**Görmen gereken:** listede `corp-internal` ve yanında çalışıyor işareti.

**Liste tamamen boşsa:** VS Code yanlış klasörü açmış. Entegre terminalde `pwd`
çalıştır — repo kökü mü?

**Hata veriyor ama output boşsa:** 2.1'e dön, `command` yanlış yorumlayıcıyı
gösteriyor.

**`corp-internal` iki kez görünüyorsa:** kullanıcı düzeyinde eski bir tanım var.
Mac'te:

```bash
ls -la "$HOME/Library/Application Support/Code/User/mcp.json"
```

Varsa geçici olarak yeniden adlandır ve pencereyi yeniden yükle:

```bash
mv "$HOME/Library/Application Support/Code/User/mcp.json" \
   "$HOME/Library/Application Support/Code/User/mcp.json.yedek"
```

---

## 2.4 — Araçları doğrula

**Ne yapıyorsun:** Copilot'un araçları gerçekten gördüğünü kanıtlıyorsun.

Sohbete `#` yaz.

**Görmen gereken:** açılan listede beş araç — `#standards_list`,
`#standard_get`, `#api_search`, `#can_deploy`, `#tool_cost`.

**Liste çıkmıyorsa** doğrudan sor:

```
standards_list aracını çalıştır
```

**Görmen gereken:** **"Allow tool from corp-internal"** istemi. Bu istem geldiyse
her şey çalışıyor demektir. **Allow** de.

Ardından üç standardın listesi dönmeli: `java-service`, `data-access`,
`ai-assistant-usage`.

**Araç bilmediğini söylüyorsa:** rol seçicisi **Agent**'ta değil. 0.7'ye dön.

---

## 2.5 — Üç soruyu sor

**Ne yapıyorsun:** araçları gerçek sorularla kullanıyorsun. Her birini **ayrı
sohbette** sor.

```
Hangi dahili API'ler kişisel veri içermiyor?
```

```
Bugün üretime çıkabilir miyiz?
```

```
14 Ağustos 2026'da deploy edebilir miyiz?
```

**Görmen gereken:** üçüncüsü **hayır** demeli ve gerekçesini de vermeli —
"Month-end reconciliation window".

**Buradaki asıl ders:** araç sadece `false` döndürmüyor, nedenini de döndürüyor.
Model gerekçeyi uyduramıyor, alıntılamak zorunda. İyi araç tasarımının işareti bu.

**Her çağrıdan önce izin istemini oku.** O istem Lab 2'nin ana konusu: her araç
çağrısı, bir insanın belirli bir anda verdiği bir karar. Denetim izini anlamlı
kılan şey o.

---

## 2.6 — Geliştirici kolu: araç yaz

**Süre:** 25 dakika

**Ne yapıyorsun:** kataloğa yeni bir araç ekliyorsun.

### Adım 1: aracı yaz

`mcp_server/corp_server.py` dosyasını aç. `tool_cost` fonksiyonunun **üstüne**
ekle:

```python
@mcp.tool()
def find_service_owner(service_name: str) -> str:
    """Bir servisten sorumlu ekibi döndürür.

    Kullanıcının bir servis hakkında kime başvuracağını bilmesi gerektiğinde
    kullan — kayıt açmadan veya olayı yükseltmeden önce. Elinde yalnızca
    kısmi bir isim varsa önce api_search çağır.

    Args:
        service_name: API kataloğundaki anahtar veya ad.
    """
    servis = API_CATALOGUE.get(service_name)
    if not servis:
        return json.dumps(
            {"error": f"'{service_name}' bulunamadı.",
             "available": sorted(API_CATALOGUE)},
            ensure_ascii=False,
        )
    return json.dumps(
        {"service": servis["name"], "owner_team": servis["owner_team"],
         "criticality": servis["criticality"]},
        ensure_ascii=False,
    )
```

Üç tasarım kararına dikkat et:

- **Docstring "ne zaman çağrılacağını" söylüyor**, "ne yaptığını" değil. Model
  araç seçimini buna bakarak yapıyor.
- **Bulunamayınca mevcut seçenekleri döndürüyor.** Model tahmin etmek yerine
  kendini düzeltebiliyor.
- **`contains_pii` alanını döndürmüyor.** Gereksiz alan göndermemek hem maliyet
  hem güvenlik kararı.

### Adım 2: import satırını güncelle

`tests/test_mcp_tools.py` dosyasının başındaki import listesine ekle:

```python
from mcp_server.corp_server import (
    api_search,
    can_deploy,
    find_service_owner,
    standard_get,
    standards_list,
    tool_cost,
)
```

### Adım 3: testleri yaz

Aynı dosyanın sonuna:

```python
def test_find_service_owner_returns_the_team():
    result = call(find_service_owner, service_name="limit-engine")
    assert result["owner_team"] == "Credit Technology"


def test_unknown_service_lists_alternatives():
    result = call(find_service_owner, service_name="nope")
    assert "error" in result
    assert "limit-engine" in result["available"]
```

### Adım 4: çalıştır

```bash
python -m pytest tests -q
```

**Görmen gereken:** `30 passed`

**`NameError: name 'find_service_owner' is not defined` alıyorsan:** Adım 2'yi
atladın, import satırı eksik.

### Adım 5: canlı dene

`Cmd+Shift+P` → **MCP: Restart Server**. Sonra sohbete:

```
Limit motorunun sahibi kim?
```

**Görmen gereken:** izin istemi, ardından "Credit Technology".

---

## 2.7 — Analist kolu: araçları değerlendir

**Süre:** 25 dakika

**Ne yapıyorsun:** araç yazmıyorsun. Daha zor olan soruyu yanıtlıyorsun: hangi
araç olmamalı.

`mcp_server/corp_server.py` dosyasını aç, beş docstring'i oku ve dört soruya
**yazılı** cevap ver:

**1.** Hangi açıklama modelin yanlış aracı seçmesine yol açabilir? Yeniden yaz.

**2.** `api_search` aracının `pii_free_only` parametresi olmasaydı ne bozulurdu?

**3.** Bu sunucuya **eklenmemesi** gereken bir araç söyle ve nedenini savun.
Somut ol: hangi veriyi döndüreceğini ve neyin ters gideceğini adıyla yaz.

**4.** `can_deploy` verdiktin yanında gerekçe de döndürüyor. Sadece
`true`/`false` dönseydi ne kaybederdik?

Değerlendirmede **ilk siz sunuyorsunuz.** İki dakika.

**Bu kolay kol değil.** Bankada asıl kritik soru bir aracın *yazılmaması*
gerektiği ve bu soru Python bilene değil, iş sonucunu bilene ait.

---

## 2.8 — Sunucunun maliyetini gör

**Ne yapıyorsun:** bağlı bir sunucunun her isteğe ne kattığını ölçüyorsun.

Sohbete:

```
tool_cost aracını çalıştır
```

**Görmen gereken:** her aracın yaklaşık token sayısı ve toplam.

Şimdi hesabı sesli yap: sekizer araçlı on sunucu, sorduğun **her sorunun**
başına seksen araç şeması ekler. Copilot'un tavanı istek başına 128 araç, ama
kalite bozulması çok daha önce başlar — model bunlar arasından seçmek zorunda.

**Kural:** bugün kullanmadığın sunucuyu kapat. Sunucu bağlamak bedava değil.

---

## Lab 2 sorun giderme

| Belirti | Sebep | Çözüm |
|---|---|---|
| Liste tamamen boş | VS Code yanlış klasörü açmış | Entegre terminalde `pwd` |
| Hata var, output boş | `command` yanlış yorumlayıcı | 2.1'i tekrarla |
| `corp-internal` iki kez | Kullanıcı düzeyi tanım çakışıyor | User `mcp.json`'ı yeniden adlandır |
| Sunucu çalışıyor, araç yok | Rol Agent'ta değil | 0.7 |
| `command not found: pip` | venv aktif değil | `source .venv/bin/activate` |
| `spawn python ENOENT` | Hâlâ düz `python` yazılı | 2.1 |
| `analyst` modu menüde yok | Pencere yeniden yüklenmemiş | `Developer: Reload Window` |

---

## Lab 2 kontrol listesi

- [ ] `mcp.json` tam yollarla yazıldı, ikisi de `.venv` içeriyor
- [ ] Sunucu elle çalıştırıldı ve dondu
- [ ] VS Code'da başladı, beş araç görünüyor
- [ ] Üç soru soruldu, üçüncüsü gerekçeli hayır döndü
- [ ] Geliştirici: `find_service_owner` yazıldı, `30 passed`, canlı çalışıyor
- [ ] Analist: dört soruya yazılı cevap
- [ ] `tool_cost` çalıştırıldı, hesap yapıldı

---

# BÖLÜM 3 — Lab 3: Ölçüm

**Süre:** 45 dakika · **Gereken:** Bölüm 0 tamamlanmış

**Hedef:** tahmini ölçümle değiştirmek ve üç eşiği kendi terminalinde
doğrulamak.

---

## 3.1 — Gerçek rakamını bul

**Ne yapıyorsun:** kendi kurumunun rakamını çekiyorsun.

Tarayıcıda: **GitHub → Settings → Billing → Usage**

Üç şeyi yaz:

| | Senin rakamın |
|---|---|
| Bu ay harcanan AI Credits | |
| Karışımda hangi modeller var | |
| Dahil kredinin yüzde kaçı | |

**Erişimin yoksa:** eğitmen kendi ekranını gösterecek. Ama kurumunda **kimin**
erişimi olduğunu öğren — önümüzdeki ay ona ihtiyacın olacak.

**Bu adımı atlama.** Sonraki her şey bu rakama dayanıyor. Tahminle bütçe kurmak,
ölçmemenin kibarcasıdır.

---

## 3.2 — Senaryo scriptini çalıştır

```bash
python cost/scenarios.py
```

**Görmen gereken** (son satırlar):

```
  Scenario                               Monthly      Allowance used
  ------------------------------------------------------------------
  Before optimisation             $     3,064.32              134.4%
  After model routing             $     1,333.68               58.5%
  After context discipline        $       456.37               20.0%
  ------------------------------------------------------------------

  Total saving: $2,607.95/month · $31,295.38/year (85.1%)
```

Üç senaryo, aynı iş, üç fiyat. Birincisi aşımda, üçüncüsü havuzun beşte birinde.

---

## 3.3 — Kendi ekibine kalibre et

**Ne yapıyorsun:** modeli kendi gerçekliğine yaklaştırıyorsun.

`cost/scenarios.py` dosyasını aç. En üstteki üç sabiti değiştir:

```python
SEATS = 120           # kendi ekip büyüklüğün
WORKDAYS = 21
ALLOWANCE = 19.0      # Business 19, Enterprise 39
```

Sonra `baseline` profilindeki `interactions_per_dev_per_day` listesini kendi
ekibinin çalışma biçimine göre yaz — günde kaç sohbet, her biri kabaca ne kadar
bağlam, hangi model.

Tekrar çalıştır ve **3.1'deki gerçek rakamla karşılaştır.**

Aralarında büyük fark varsa hatalı olan hesaplayıcı değil, senin kullanım
varsayımların. Kabaca tutana kadar düzelt.

**Bu kalibrasyonun kendisi uygulamanın asıl kısmı.** Sonuç değil, süreç önemli.

---

## 3.4 — Üç eşiği doğrula

**Ne yapıyorsun:** slaytlardaki rakamları kendi terminalinde kanıtlıyorsun.

### a) Model seçimi — 25 kat

```bash
python -c "
import sys; sys.path.insert(0,'.')
from cost.calculator import Interaction
for m in ('gpt-5.6-luna','gpt-5.6-terra','gpt-5.6-sol'):
    i = Interaction(m, input_tokens=100_000, output_tokens=3_000)
    print(f'{m:>16}  \${i.cost_usd():.4f}  {i.credits():>6.1f} kredi')
"
```

**Görmen gereken:**

```
    gpt-5.6-luna  $0.0236     2.4 kredi
   gpt-5.6-terra  $0.2360    23.6 kredi
     gpt-5.6-sol  $0.5900    59.0 kredi
```

Aynı soru, aynı iş. En ucuzla en pahalı arasında 25 kat.

### b) Önbellek — 10 kat

```bash
python -c "
import sys; sys.path.insert(0,'.')
from cost.calculator import Interaction
tam = Interaction('gpt-5.6-terra', input_tokens=100_000)
onb = Interaction('gpt-5.6-terra', cached_input_tokens=100_000)
print(f'tam        \${tam.cost_usd():.4f}')
print(f'onbellekli \${onb.cost_usd():.4f}')
print(f'oran       {tam.cost_usd()/onb.cost_usd():.1f}x')
"
```

**Görmen gereken:**

```
tam        $0.2000
onbellekli $0.0200
oran       10.0x
```

Şimdi dürüst tarafı — Anthropic modellerinde önbelleğe **yazmanın** maliyeti var:

```bash
python -c "
import sys; sys.path.insert(0,'.')
from cost.calculator import RATES
r = RATES['claude-sonnet-5']
print(f'girdi {r.input_}  onbellekli {r.cached_input}  onbellek yazma {r.cache_write}')
"
```

**Görmen gereken:** `girdi 2.0  onbellekli 0.2  onbellek yazma 2.5`

Yazma, düz girdiden pahalı. Önbellek bir yatırım — tekrar kullanımda geri
dönüyor, kısa ömürlü bağlamda zarar bile ettirebiliyor.

### c) Uzun bağlam — 2 kat

```bash
python -c "
import sys; sys.path.insert(0,'.')
from cost.calculator import Interaction
for n in (270_000, 280_000):
    i = Interaction('gpt-5.6-terra', input_tokens=n, output_tokens=3_000)
    print(f'{n:>9,} token -> \${i.cost_usd():.4f}  uzun_baglam={i.breakdown()[\"long_context\"]}')
"
```

**Görmen gereken:**

```
  270,000 token -> $0.5760  uzun_baglam=False
  280,000 token -> $1.1740  uzun_baglam=True
```

**%3,7 daha çok token, %104 daha çok para.** Kademe yok, 272K'da uçurum var.

---

## 3.5 — Kendini ölç (A/B koşusu)

**Ne yapıyorsun:** iki kurulumu gerçek bir işte karşılaştırıyorsun.

Bir görev seç. Örneğin "şu servis çağrısına zaman aşımı ekle".

**A koşusu:** bağlama beş dosya ekle, güçlü model, uzun süren bir sohbetin
ortasında sor.

**B koşusu:** yeni sohbet, sadece ilgili dosya, hafif model, net tek istek.

İki koşu arasında GitHub kullanım raporunu kontrol et.

| | A koşusu | B koşusu |
|---|---|---|
| Kullanılan model | | |
| Bağlamdaki dosya sayısı | | |
| Harcanan kredi | | |
| Cevap kabul edilebilir mi? | | |

**Beklenen büyüklük** (modellenmiş örnek):

| | Model | Girdi | Maliyet |
|---|---|---|---|
| A | Sol | 95.000 | $0,5110 · 51 kredi |
| B | Luna | 6.000 | $0,0023 · 0,2 kredi |

Oran: **224 kat.**

**Asıl öğretici kısım — değişkenleri ayır:**

| Değişen | Kazanç |
|---|---|
| Sadece model (bağlam aynı) | 25x |
| Sadece bağlam (model aynı) | 9x |
| İkisi birden | **224x** |

25 × 9 = 225. **Kaldıraçlar toplanmıyor, çarpılıyor.**

**Dördüncü satır boşsa ölçüm geçersizdir.** Kendine sor: B'nin cevabını gerçekten
kullanır mıydın, yoksa A'yı görmüş olduğun için mi kabul edilebilir göründü?

Hafif model işe yaramadıysa bu bir **başarısızlık değil, bulgu**. Hangi görevdi,
neyi kaçırdı? Cevap, Lab 4'teki yönlendirme tablosunun "güçlü model" satırına
gider.

---

## Lab 3 kontrol listesi

- [ ] Gerçek kullanım rakamı yazıldı
- [ ] `scenarios.py` kendi ekip büyüklüğüne kalibre edildi
- [ ] Üç eşik kendi terminalinde doğrulandı (25x, 10x, 2x)
- [ ] A/B koşusu yapıldı, **dört satır da** dolduruldu

---

# BÖLÜM 4 — Lab 4: Optimizasyon

**Süre:** 60 dakika · **Gereken:** Lab 3 tamamlanmış

**Hedef:** ölçtüğün rakamı düşürmek, sonra tekrar ölçmek.

---

## 4.1 — Her dosyayı tart

```bash
python -c "
import sys; sys.path.insert(0,'.')
from cost.calculator import estimate_tokens
from pathlib import Path
toplam = 0
for f in sorted(Path('.github').rglob('*.md')):
    t = estimate_tokens(f.read_text()); toplam += t
    print(f'{t:>6} token  {f}')
print(f'{toplam:>6} token  TOPLAM')
"
```

**Görmen gereken:**

```
   279 token  .github/chatmodes/analyst.chatmode.md
   292 token  .github/copilot-instructions.md
   130 token  .github/instructions/data-jobs.instructions.md
   310 token  .github/instructions/java-service.instructions.md
   188 token  .github/prompts/release-check.prompt.md
   221 token  .github/prompts/service-review.prompt.md
  1420 token  TOPLAM
```

Şimdi **kendi reponda** çalıştır. O rakam bugün üzerinde çalışacağın şey.

**Tahminler sadece sezgi için.** Gerçek tokenizasyon modele özgü ve Türkçe metin
aynı içerik için İngilizceden belirgin biçimde fazla token üretiyor. Rapor
edeceğin hiçbir şeyde tahmin kullanma.

---

## 4.2 — Always-on dosyayı kes

**Ne yapıyorsun:** kendi `copilot-instructions.md` dosyanı küçültüyorsun.

Her satıra Lab 1'deki testi uygula:

| Oran | Ne yap |
|---|---|
| %80+ | bırak |
| %20–80 | `instructions/` + `applyTo` |
| %20 altı | `.prompt.md` |

**Hedef: 500 token altı.** Repodaki örnek 292.

Tipik kurumsal dosyada ne kesilir:

| İçerik | Nereye |
|---|---|
| Spring Boot katman kuralları | `instructions/` + `applyTo: "**/*.java"` |
| pandas/numpy kuralları | `instructions/` + `applyTo: "**/*.py"` |
| Kod inceleme kontrol listesi | `.prompt.md` |
| Onboarding metni, takım tanıtımı | Wiki — model bunu okumuyor bile |
| Commit mesajı formatı | `.prompt.md` veya git hook |

**Tasarrufu paraya çevir:**

```
çıkarılan_token × kişi_başı_günlük_istek × kişi × iş_günü = token/ay
```

120 kişi, günde 4 istek, 21 gün varsayımıyla:

| Kesilen | Aylık token | Dengeli model | Yıllık |
|---|---|---|---|
| 500 token | 5,04M | $10,08 | $121 |
| 1.000 token | 10,08M | $20,16 | $242 |
| 2.000 token | 20,16M | $40,32 | $484 |

Güçlü modelde bu rakamlar 2,5 katına çıkar.

**Sahte sonucun işareti:** dosyayı küçülttün ama hiçbir satırı **taşımadıysan**,
muhtemelen gerçekten gerekli kuralları sildin. Kestiğin satırlar nereye gitti?

---

## 4.3 — Model yönlendirme tablosunu yaz

**Ne yapıyorsun:** ekibin için bir sayfa hazırlıyorsun.

| İş türü | Model sınıfı | Gerekçe |
|---|---|---|
| Satır içi tamamlama | varsayılan | hiç ölçülmüyor |
| Basit soru, kod okuma | hafif | muhakeme gerekmiyor |
| Hata ayıklama, refactor | dengeli | günlük işin dürüst ortası |
| Mimari, karmaşık agent işi | güçlü | fiyatını hak ediyor |
| Kod incelemesi | seçici | koşu başına pahalı |

İyi bir tablonun üç özelliği:

- **Model adı değil, sınıf yazar.** "GPT-5.6 Terra" yazan tablo altı ay sonra
  ölür; "dengeli" yazan yaşar.
- **İş türüne göre yazılır, kişiye göre değil.** Kıdemli bir geliştiricinin PR
  açıklaması da hafif modelle yazılır.
- **Aşma yolunu tanımlar.** "Cevap yeterli değilse güçlü modele geç" tabloda
  yazılı olmalı.

İki karar daha ver:

**Yeni sohbetin varsayılan modeli ne?** Doğru cevap neredeyse her zaman hafif.
Yükseltmek bir tıklama, ama güçlü modelde başlayıp fark etmemek bütün gün
sürebilir. **Varsayılan, unutulduğunda geçerli olan şeydir** — ucuz tarafta
dursun.

**Kim aşabilir?** Herkes. Ama ölçüm ritmi varsa ay sonunda karışım raporunda
görünür. Denetim, izin zorunluluğundan iyi çalışır ve kimseyi yavaşlatmaz.

> **Bu tabloyu `copilot-instructions.md`'ye koyma.** Günün en ironik hatası:
> maliyeti düşürmek için yazılan tablo, her isteğe eklenerek maliyeti artırır.
> Üstelik modelin karar vermediği bir şeyi modele anlatır. Wiki'ye koy.

---

## 4.4 — Gerçek işte önce/sonra

**Ne yapıyorsun:** bu hafta gerçekten yaptığın bir işi iki kez yapıyorsun.

**Önce:** klasörün tamamı bağlamda, güçlü model, uzun sohbetin ortasında.

**Sonra:** yeni sohbet, sadece ilgili dosya, hafif model, net tek istek.

| | Önce | Sonra |
|---|---|---|
| Kullanılan model | | |
| Bağlamdaki dosya sayısı | | |
| Harcanan kredi | | |
| Cevap kabul edilebilir mi? | | |

**İyi sonuç neye benzer:** 10x–100x arası kredi düşüşü, aynı veya kabul edilebilir
kalite, ve genelde **daha kısa süre** — az bağlam sadece ucuz değil, hızlı.

**Sahte sonucun üç işareti:**

1. Kalite satırı boş ya da gerekçesiz "iyi" yazıyor
2. "Sonra" koşusu farklı bir iş — kolay görevi hafif modele vermek ölçüm değil,
   seçim
3. Kredi düşüşü çok büyük ama iş yarım kalmış

**Kalite düştüyse** sırayla dene:

1. Bağlamı aynı bırak, **sadece modeli** yükselt. Kalite dönüyor mu?
2. Model aynı kalsın, **sadece bir dosya** ekle. Kalite dönüyor mu?

Bu ikisini **ayrı ayrı** yap. Aynı anda ikisini birden geri alırsan hangisinin
gerektiğini asla öğrenemezsin — ve gereksiz olanı sonsuza kadar ödersin.

---

## 4.5 — Eylem planı

**Ne yapıyorsun:** üç satır yazıyorsun. Sadece üç.

1. **Yarın:** kimseden izin almadan uygulayabileceğin bir kural.
2. **Bu çeyrek:** bir karar veya sahip gerektiren bir değişiklik.
3. **Hâlâ eksik:** karar verebilmek için ihtiyacın olan bir veri.

Bunu sakla. Takip oturumunda karşılaştırılacak şey bu.

---

## Lab 4 kontrol listesi

- [ ] `.github` altındaki dosyalar tartıldı, kendi repon da ölçüldü
- [ ] Always-on dosya 500 token altına indirildi, tasarruf paraya çevrildi
- [ ] Model yönlendirme tablosu yazıldı — wiki'ye, repoya değil
- [ ] Önce/sonra ölçümü yapıldı, **kalite satırı dahil** dört satır dolu
- [ ] Üç satırlık eylem planı yazıldı

---

# Baştan sona kontrol

Hepsini tamamladıysan şunlar elinde olmalı:

- [ ] Çalışan bir kurulum: VS Code, Agent modu, bağlı MCP sunucusu
- [ ] Kendi gerçek kullanım rakamın
- [ ] Kendi ekibine kalibre edilmiş bir maliyet modeli
- [ ] Üç eşik, kendi terminalinde doğrulanmış
- [ ] Kesilmiş bir always-on dosya ve parayla ifade edilmiş tasarrufu
- [ ] Bir model yönlendirme tablosu
- [ ] Kalite satırı dolu bir önce/sonra ölçümü
- [ ] Üç satırlık eylem planı

**Eğitmensen ayrıca:** her adımın gerçekte kaç dakika sürdüğü ve takıldığın her
yer. O notlar metni düzeltmek için en değerli veri — yazan süreler tahmin, senin
ölçtüğün gerçek.
