# IntelliJ / JetBrains sürümü

Bu klasör, atölyenin JetBrains IDE'lerde verilen sürümü için değişen lab
dosyalarını içeriyor.

## Hangi lab nereden

| Lab | Dosya | Neden |
|---|---|---|
| Lab 1 | `labs/intellij/LAB-1-talimat-dosyalari.md` | `applyTo` ve chat mode yok |
| Lab 2 | `labs/intellij/LAB-2-mcp-sunucusu.md` | MCP ayar arayüzünden tanımlanıyor |
| Lab 3 | `labs/LAB-3-olcum.md` | **Değişmiyor** — IDE'den bağımsız |
| Lab 4 | `labs/LAB-4-optimizasyon.md` | **Değişmiyor** — IDE'den bağımsız |

## Üç temel fark

**1. Kapsamlı talimat dosyaları yok.** JetBrains repo başına tek bir
`.github/copilot-instructions.md` okuyor. `instructions/` klasöründeki
`applyTo` glob'lu dosyalar okunmuyor. Repoda duruyorlar ama etkisizler.

**2. Chat mode yok.** `.chatmode.md` desteklenmiyor. Analist modu bu sürümde
`.github/prompts/analist.prompt.md` olarak çalışıyor — davranışsal sınır
korunuyor, araç kısıtlaması kayboluyor.

**3. MCP yapılandırması repoda değil.** Copilot ikonu → Edit Settings →
Model Context Protocol → Configure. Ekiple paylaşılmıyor, PR'da incelenmiyor,
her geliştirici kendi kuruyor.

## JetBrains'e özel iki ek konu

**`global-copilot-instructions.md`** — makinede duran, tüm projelere uygulanan
yerel bir talimat dosyası. VS Code'da karşılığı yok. Her isteğe giriyor ve
kimse incelemiyor; sahiplik tartışmasına doğrudan malzeme.

**Uzak MCP sunucularında PAT gerekiyor.** JetBrains henüz OAuth desteklemiyor,
kişisel erişim token'ı kullanılıyor. Bankada token'ın kimde ve nerede durduğu
ayrı bir konu.

## Değişmeyenler

Token ekonomisinin tamamı, yedi kaldıraç, MCP sunucu kodu, maliyet
hesaplayıcısı ve 28 test aynen geçerli.
