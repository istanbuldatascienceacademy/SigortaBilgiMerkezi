# IntelliJ sürümü — eğitmen anlatım notu

Bu belge, atölyeyi JetBrains IDE kullanan bir ekibe verirken neyin değiştiğini
ve değişen her slaytta ne söyleneceğini anlatır.

**Yanında kullanacağın dosyalar:**

| Dosya | Ne için |
|---|---|
| `Copilot-Atolyesi-IntelliJ-Degisen-Slaytlar.pptx` | Ana sunuma yerleştireceğin 12 slayt |
| `labs/intellij/LAB-1-talimat-dosyalari.md` | Lab 1'in IntelliJ sürümü |
| `labs/intellij/LAB-2-mcp-sunucusu.md` | Lab 2'nin IntelliJ sürümü |
| `labs/LAB-3-olcum.md` · `labs/LAB-4-optimizasyon.md` | Değişmedi, aynen kullan |

---

## Sunumu hazırlama

Ana sunumu aç, aşağıdaki slaytları yenileriyle değiştir. Paketin her slaydının
sağ üstünde hangi slaytın yerine geçtiği yazılı.

| Paket slaydı | Ne yap | Ana sunumda |
|---|---|---|
| 3 — Başlamadan önce | Değiştir | Slayt 8 |
| 4 — İki dosya, iki iş | Değiştir | Slayt 10 |
| 5 — Bu kural nereye gider | Değiştir | Slayt 11 |
| 6 — Kapsamlama yok | Değiştir | Slayt 14 |
| 7 — Analist modu | Değiştir | Slayt 16 |
| 8 — Global talimat dosyası | **Ekle** | Slayt 17'den sonra |
| 9 — Yapılandırma repoda değil | Değiştir | Slayt 24 |
| 10 — Karma ekip sorunu | **Ekle** | Slayt 17'den sonra veya M1 sonunda |
| 11 — Lab 2 brifingi | Değiştir | Slayt 34 |

Paketteki 1, 2 ve 12 numaralı slaytlar **senin için** — odaya gösterme, hazırlık
sırasında oku.

**Sonuç:** 60 slayt → 62 slayt. M3 ve M4'ün tamamına dokunulmuyor.

---

## Üç gün önce sorulacaklar

VS Code sürümündeki ön koşul listesine iki madde ekle:

- [ ] **Copilot eklentisi güncel mi?** Eski sürümlerde ayarlarda Model Context
      Protocol bölümü hiç görünmüyor ve Lab 2 çalışmıyor. Katılımcılardan
      eklenti sürümünü yazılı isteyin.
- [ ] **MCP politikası JetBrains için açık mı?** "MCP servers in Copilot"
      politikası VS Code'a uygulanıyor; JetBrains geçiş sürecinde. Yöneticiye
      ikisini birden sor — kapı aynı yerde olmayabilir.

Python kontrolü aynı kalıyor: `python3 --version` (3.10+) ve `which python3`
çıktılarını yazılı iste.

---

## Slayt slayt anlatım

### Paket 3 — Başlamadan önce (Slayt 8 yerine)

**2–3 dk.** İlk iki kart VS Code sürümüyle aynı; hızlı geç. Kırmızı kartta dur.

> "İki şeyi eğitimden önce teyit ettirmeniz lazım. Birincisi eklenti sürümü —
> eski bir Copilot eklentisinde ayarlarda Model Context Protocol bölümü hiç
> görünmüyor ve öğleden önceki ikinci lab çalışmıyor. İkincisi politika: MCP
> izni şu an VS Code tarafında tanımlı, JetBrains geçiş sürecinde. Yöneticinize
> ikisini birden sorun."

Sonra odaya sor: **"Kimin ayarlarında Model Context Protocol bölümü görünüyor?"**
El kaldırtan say. Eksik varsa şimdi çöz, 11:45'te değil.

---

### Paket 4 — İki dosya, iki iş (Slayt 10 yerine)

**4 dk.** Tabloyu yukarıdan aşağı oku. Son iki satırda yavaşla.

> "Son iki satır VS Code'da çalışıyor, burada çalışmıyor. 'Okunmuyor' demek,
> dosyanın repoda durup hiçbir şey yapmaması demek. Maliyet de üretmiyor — ama
> fayda da sağlamıyor."

İkinci satır yeni: `global-copilot-instructions.md`. Şimdilik sadece adını
geçir; paket 8'de açacaksın.

Karar kuralını tahtaya yaz — VS Code sürümüyle aynı, değişen tek şey gidecek
yer sayısı:

> **Her soruda gerekli değilse, her istekte yüklenen dosyaya girmez.**

---

### Paket 5 — Bu kural nereye gider (Slayt 11 yerine)

**3 dk.** Ağaç iki dallı. Bunu kayıp olarak sunma, basitleşme olarak sun — ama
sonucunu söyle.

> "VS Code'da bu ağacın dört dalı vardı. Burada iki. Yani prompt dosyalarına
> daha çok iş düşüyor; teknolojiye özgü kuralların, tekrarlanan görevlerin ve
> farklı çalışma kiplerinin hepsi aynı yere gidiyor. Bu da onları yazma
> disiplinini daha önemli hâle getiriyor."

---

### Paket 6 — Kapsamlama yok (Slayt 14 yerine)

**4 dk.** Bu slayt, VS Code sürümündeki canlı `applyTo` demosunun yerine geçiyor.
Demo yapamadığın için kavramı anlatıp hemen uygulamaya bağla.

Sol kart (kaybedilen) ve sağ kart (elinizde kalan) üzerinden geç, sonra koyu
kutuyu oku:

> "Kapsamlama fikri hâlâ doğru — ilgisiz bağlam hem para yakıyor hem modeli
> şaşırtıyor. JetBrains bunu dosya düzeyinde otomatik yapamıyor. Ama siz çağrı
> düzeyinde yapabilirsiniz: detayı prompt dosyasına koyup yalnızca gerektiğinde
> çağırmak aynı işi görüyor. Farkı, bir tık."

Org düzeyinde talimatlara geldiğinde (slayt 17) bu ayrımı hatırlat: orada
kapsamlama hâlâ mümkün.

---

### Paket 7 — Analist modu (Slayt 16 yerine)

**4 dk.** Demo hâlâ yapılabiliyor, sadece açılışı farklı.

**Canlı göster:**

1. Sohbete `/analist` yaz
2. "Sürüm takvimi kuralları nerede tanımlı ve ne diyor?" diye sor
3. Sonra "Bana bir servis sınıfı yaz" de
4. Reddedişi odaya izlettir

> "Sınırını tutan bir kural, anlattığım bir kuraldan çok daha ikna edici."

Sağdaki tabloda ikinci satırda dur ve dürüst ol:

> "Chat mode'da `tools` alanı araç erişimini de kısıtlıyordu — az araç, bağlamda
> az şema, ucuz cevap. Prompt dosyasında bu kazanç yok. Davranışsal sınır
> kalıyor, maliyet kazancı kalmıyor."

**Sorarlarsa:** prompt dosyası sohbet uzadıkça zayıflayabilir, chat mode gibi
kalıcı değil. Uzun sohbette tekrar `/analist` yazmaları gerekebilir.

**Analistlere bakarak anlat.** Bu slayt onların slaydı; VS Code sürümünde de
öyleydi.

---

### Paket 8 — Global talimat dosyası (Slayt 17'den sonra, YENİ)

**3 dk.** Ana sunumda karşılığı yok, tamamen yeni.

Üç kartı sırayla aç, sonra koyu kutuyu oku:

> "Repodaki dosya için 'kim değiştirebilir' diye sormuştuk. Bu dosya için soru
> daha zor: kimse göremiyor, kimse inceleyemiyor — ama maliyeti ve etkisi aynı."

Sonra odaya sor: **"Kaçınızın makinesinde böyle bir dosya var?"**

Genelde kimse bilmiyor. Zaten mesele bu.

---

### Paket 10 — Karma ekip sorunu (M1 sonunda, YENİ)

**3 dk.** Çoğu kurumda gerçek durum karma ve kimse bunu konuşmamış oluyor.

Koyu kutuyu oku, sonra üç kartı geç. Ardından **el kaldırt:**

> "Kaçınız VS Code kullanıyor? Kaçınız IntelliJ?"

Oran kararı belirliyor:
- **90/10** → çoğunluğa göre optimize et
- **50/50** → iki katmanlı yaklaşım, tekrarı göze al

Kapanış atölyesinde bu bir soru olarak geri gelecek: talimat dosyası sahipliği
kararı, IDE dağılımını da kapsamalı.

---

### Paket 9 — Yapılandırma repoda değil (Slayt 24 yerine)

**3 dk.** Bu, Lab 2'nin kurulum adımını doğrudan değiştiren slayt.

Üstteki iki kutuyu göster (nereden açılır, değişken yok), sonra tabloyu satır
satır oku. **Üçüncü satırda dur:**

> "Repoda duran bir yapılandırma incelenebilir bir karardır. IDE ayarında duran,
> kimsenin görmediği bir karardır."

Bunu onaylı sunucu listesi konusuyla (slayt 28) bağla:

> "Birazdan onaylı sunucu listesinden bahsedeceğim. Şimdi şunu düşünün: liste
> var diyelim, uygulandığını nereden bileceksiniz?"

Cevap genelde yok. İyi.

---

### Paket 11 — Lab 2 brifingi (Slayt 34 yerine)

**2 dk.** Beş adımı hızlı geç, iki şeyi vurgula.

**Birincisi:** Adım 1'e 10 dakika ayır (VS Code sürümünde 15'ti). `mcp.json`
üreteci olmadığı için adım sayısı az, ama elle yazma riski yüksek. Dolaşırken
tam yolların doğru kopyalandığını kontrol et.

**İkincisi:** analist kolunun beşinci sorusu yeni ve en iyisi:

> "Yapılandırma IDE'de durduğu için, bir denetçi 'bu ekip hangi MCP sunucularını
> bağlamış' diye sorsa cevabı nereden bulursunuz?"

Denetlenebilirlik sorusu doğrudan bu IDE farkından çıkıyor. Değerlendirmede
analist grubunu yine ilk konuştur.

---

## Lab yönetimi

### Lab 1 (45 dk)

VS Code sürümüyle aynı akış, iki fark:

- **Adım 3 değişti:** `applyTo` demosu yerine "kapsamlama yok, ne yapacaksınız"
  tartışması. Katılımcılar `java-service.instructions.md` içeriğinin nereye ait
  olduğuna karar verip bir cümleyle yazıyor. Lab 4'te o kararı uygulayacaklar.
- **Adım 5 değişti:** analist modu `/analist` ile açılıyor.

Dolaşırken Adım 2'deki satır satır tartışmaya vakit ayır — labın kendisi o.

### Lab 2 (60 dk)

**Adım 2 en kritik yer.** Katılımcılar iki tam yolu ayar arayüzüne elle
yazacak. En sık hata: `python` yazıp tam yol yazmamak, veya `.venv` parçasını
atlamak.

Dolaşırken üç şeyi kontrol et:
1. `(.venv)` komut isteminde görünüyor mu
2. Ayar arayüzüne yazılan iki yol da `.venv` içeriyor mu
3. Sunucu elle çalıştırıldığında donuyor mu

**JetBrains'te MCP: Restart Server komutu yok.** Sunucu kodunu değiştirdikten
sonra ayarlardan MCP yapılandırmasını açıp kaydetmeleri veya IDE'yi yeniden
başlatmaları gerekiyor. Bunu Adım 5'te hatırlat.

### Lab 3 ve Lab 4

Değişmedi. VS Code sürümünü aynen kullan — `labs/LAB-3-olcum.md` ve
`labs/LAB-4-optimizasyon.md`.

---

## Kapanış atölyesine ek

Dört başlıktan üçüncüsü (talimat dosyası sahipliği) IntelliJ'de iki ek soru
içeriyor. Grubu yönlendir:

- Global talimat dosyası kurum politikasına nasıl dahil edilecek? Kimse
  göremiyorken nasıl denetlenecek?
- Karma ekipte aynı repo iki geliştiricide farklı davranıyor. En küçük ortak
  payda mı, iki katmanlı yapı mı?

İkinci başlık (MCP onay süreci) de değişiyor: yapılandırma repoda olmadığı için
onaylı liste nasıl uygulanacak? Güvene mi dayanılacak, yoksa merkezî bir
politika mı olacak?

---

## Hazırlık kontrol listesi

- [ ] Ana sunumda dokuz slayt değiştirildi/eklendi
- [ ] Katılımcılara `labs/intellij/` altındaki iki lab dosyası verildi
- [ ] Lab 3 ve Lab 4 için ana klasördeki dosyalar verildi
- [ ] Eklenti sürümü ve MCP politikası üç gün önce teyit edildi
- [ ] Kendi makinende IntelliJ'de Lab 2 Adım 2'yi baştan sona yaptın
- [ ] `/analist` demosu prova edildi
- [ ] `scenarios.py` içindeki `SEATS` müşterinin ekip büyüklüğüne çekildi
- [ ] `RATES` tablosu GitHub Docs'tan doğrulandı

---

## Kaynaklar

Bu sürümdeki farklar şu kaynaklardan doğrulandı:

- GitHub Docs — *Adding repository custom instructions for GitHub Copilot in
  your IDE* (JetBrains'te tek dosya desteği, prompt dosyaları, global dosya)
- github/github-mcp-server — *Install in other Copilot IDEs* (JetBrains'te MCP
  ayar arayüzünden, PAT gereksinimi, politika farkı)

Bu alan hızlı değişiyor. Eğitimden önce ikisini de tekrar kontrol et; özellikle
MCP politikasının JetBrains'e uygulanıp uygulanmadığını.
